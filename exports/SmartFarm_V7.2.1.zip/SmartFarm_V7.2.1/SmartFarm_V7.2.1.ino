// SmartFarm V7.2.1 - hardened ESP8266 controller + physical AP setup button
// Hardware: DHT11 + 4 relays + DS3231
// Fixes: boot/reset diagnostics, NTP init order, reduced JSON stack usage,
// non-blocking reconnect behavior, safer WiFiManager recovery, explicit MQTT
// setup/diagnostics.

#include <Arduino.h>
#include <ArduinoJson.h>
#include <ArduinoOTA.h>
#include <DHT.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266WebServer.h>
#include <ESP8266WiFi.h>
#include <LittleFS.h>
#include <NTPClient.h>
#include <PubSubClient.h>
#include <RTClib.h>
#include <Updater.h>
#include <WiFiClientSecure.h>
#include <WiFiManager.h>
#include <WiFiUdp.h>
#include <Wire.h>
#include "emqx_secrets.h"

struct ScheduleSlot;

#define SMARTFARM_VERSION "V7.2.1-PHYSICAL-AP-BUTTON"
#define MQTT_PORT 8883
#define MQTT_BASE "smartfarm"
#define TZ_OFFSET_SECONDS (7L * 3600L)

// HTTP OTA is intended for the trusted local farm LAN only.
// Do NOT expose port 80 to the public Internet. ArduinoOTA remains available
// on UDP 8266 and is password protected.
#define ENABLE_HTTP_OTA 0
#define OTA_ARDUINO_PORT 8266
#define OTA_HTTP_PORT 80

#define RTC_SDA D3
#define RTC_SCL D4
#define DHT_PIN D2
#define RELAY_PUMP D5
#define RELAY_ZONE1 D6
#define RELAY_LIGHT_HOME D7
#define RELAY_LIGHT_SALA D8
#define SOIL_PIN A0
#define RELAY_ON LOW
#define RELAY_OFF HIGH
#define WIFI_RESET_BUTTON D1
// AP setup: momentary normally-open button from D0/GPIO16 to 3V3; hold 2 s.
#define AP_SETUP_BUTTON D0

const uint32_t WIFI_RESET_HOLD_MS = 5000UL;
const uint32_t AP_SETUP_BUTTON_HOLD_MS = 2000UL;
// First boot opens SmartFarm_Setup; WiFiManager saves the selected SSID and
// password in ESP8266 flash so later boots reconnect to the saved network.
// Close the portal after three minutes when no setup is completed.
const uint16_t WIFI_PORTAL_TIMEOUT_SECONDS = 180;
const uint32_t MQTT_RECONNECT_MS = 5000UL;
const uint32_t MQTT_RECONNECT_MAX_MS = 60000UL;
const uint32_t SENSOR_INTERVAL_MS = 30000UL;
const uint32_t HEARTBEAT_INTERVAL_MS = 10000UL;
const uint32_t SCHEDULE_INTERVAL_MS = 1000UL;
const uint32_t RTC_NTP_SYNC_INTERVAL_MS = 6UL * 60UL * 60UL * 1000UL;
const uint32_t NTP_RETRY_INTERVAL_MS = 10UL * 60UL * 1000UL;
const uint32_t MIN_VALID_EPOCH = 1704067200UL;
const char *const NTP_SERVERS[] = {"pool.ntp.org", "time.nist.gov", "asia.pool.ntp.org"};
const uint8_t NTP_SERVER_COUNT = sizeof(NTP_SERVERS) / sizeof(NTP_SERVERS[0]);
const uint8_t MQTT_AUTH_FAIL_LIMIT = 3;
const uint32_t MQTT_DIAGNOSTIC_INTERVAL_MS = 30000UL;
const uint32_t WIFI_RECONNECT_INTERVAL_MS = 15000UL;
const char MQTT_RECOMMENDED_USERNAME[] = "smartfarm-device";
const char *const MQTT_COMMAND_TOPICS[] = {
    MQTT_BASE "/relay/+/set",
    MQTT_BASE "/schedule/+/set",
    MQTT_BASE "/mode/set",
    MQTT_BASE "/emergency/set",
    MQTT_BASE "/config/telegram/set",
    MQTT_BASE "/config/telegram/test",
    MQTT_BASE "/reminder/set",
    MQTT_BASE "/ai/alert/set"};
const uint8_t MQTT_COMMAND_TOPIC_COUNT =
    sizeof(MQTT_COMMAND_TOPICS) / sizeof(MQTT_COMMAND_TOPICS[0]);

WiFiClientSecure tls;
WiFiClientSecure telegramTls;
BearSSL::X509List *mqttTrustAnchor = nullptr;
PubSubClient mqtt(tls);
ESP8266WebServer otaServer(80);
WiFiUDP udp;
NTPClient ntp(udp, "pool.ntp.org", TZ_OFFSET_SECONDS, 60000UL);
RTC_DS3231 rtc;
DHT dht(DHT_PIN, DHT11);

bool fsReady = false, rtcAvailable = false, rtcTimeValid = false, ntpTimeValid = false;
uint32_t lastRtcSync = 0, lastNtpAttempt = 0, lastMqttAttempt = 0,
         mqttRetryDelayMs = MQTT_RECONNECT_MS, lastSensor = 0,
         lastHeartbeat = 0, lastSchedule = 0, lastMqttDiagnostic = 0,
         lastWifiReconnect = 0, lastSensorValidAt = 0;
uint32_t sensorReadCount = 0, sensorFaultCount = 0;
uint32_t wifiReconnectRequests = 0, mqttConnectAttempts = 0,
         mqttConnectFailures = 0;
uint8_t mqttAuthFailures = 0;
bool mqttPortalOpened = false;
bool autoMode = true;
bool mqttConfigReported = false;
bool otaHttpRestartPending = false;
unsigned long otaHttpRestartAt = 0;
bool otaUploadFailed = false;
bool otaUploadCompleted = false;
size_t otaUploadBytes = 0;
size_t otaUploadMaxBytes = 0;
bool wifiStateKnown = false, lastWifiConnected = false;
bool wifiResetPressed = false;
bool wifiResetLatched = false;
bool apSetupButtonPressed = false;
bool apSetupButtonLatched = false;
bool otaUpdateInProgress = false;
bool otaFailureLock = false;
uint8_t otaProgressPercent = 0;
uint32_t otaStartedAt = 0;
uint32_t otaLastProgressAt = 0;
bool otaReady = false;
char otaHostname[48] = "";
uint32_t wifiResetStartedAt = 0;
uint32_t apSetupButtonStartedAt = 0;
bool mqttTlsReady = false;
bool readRtcNow(DateTime &value);
bool prepareTlsValidationTime();

bool prepareTlsValidationTime() {
  // BearSSL validates the broker certificate against its X509 clock.
  // NTPClient stores network time separately, so explicitly pass the
  // validated time to BearSSL before every TLS handshake.
  uint32_t epoch = 0;

  if (ntpTimeValid && ntp.getEpochTime() >= MIN_VALID_EPOCH) {
    epoch = ntp.getEpochTime();
    Serial.printf("MQTT TLS: X509 time from NTP=%lu\n",
                  (unsigned long)epoch);
  } else if (rtcAvailable) {
    DateTime rtcNow(2000, 1, 1);
    if (readRtcNow(rtcNow) && rtcNow.unixtime() >= MIN_VALID_EPOCH) {
      epoch = rtcNow.unixtime();
      Serial.printf("MQTT TLS: X509 time from DS3231=%lu\n",
                    (unsigned long)epoch);
    }
  }

  if (epoch < MIN_VALID_EPOCH) {
    Serial.println(F("MQTT TLS: X509 time INVALID - waiting for NTP/RTC"));
    return false;
  }

  tls.setX509Time((time_t)epoch);
  telegramTls.setX509Time((time_t)epoch);
  return true;
}

bool configureMqttTls() {
  const size_t caLength = strlen_P(MQTT_ROOT_CA_PEM);
  // MQTT_ROOT_CA_PEM lives in PROGMEM. Do not pass it as the RAM haystack to
  // strstr_P(); on ESP8266 that calls the wrong memory-space reader and can
  // trigger Fatal exception:3 immediately after Wi-Fi connects. BearSSL's
  // parser reads PROGMEM correctly and getCount() is the authoritative check.
  if (caLength < 64) {
    Serial.println(F("MQTT TLS: disabled - install the broker CA certificate first"));
    return false;
  }
  if (mqttTrustAnchor) delete mqttTrustAnchor;
  mqttTrustAnchor = new BearSSL::X509List(MQTT_ROOT_CA_PEM);
  if (!mqttTrustAnchor || mqttTrustAnchor->getCount() == 0) {
    Serial.println(F("MQTT TLS: invalid CA certificate; refusing connection"));
    delete mqttTrustAnchor;
    mqttTrustAnchor = nullptr;
    return false;
  }
  tls.setTrustAnchors(mqttTrustAnchor);
  tls.setBufferSizes(4096, 512);

  // Do not allow a TLS handshake while the ESP8266 clock is invalid.
  if (!prepareTlsValidationTime()) {
    Serial.println(F("MQTT TLS: waiting for valid NTP/DS3231 time"));
    return false;
  }

  Serial.println(F("MQTT TLS: ready"));
  return true;
}

char mqttUser[64] = "";
char mqttPass[96] = "";
char otaPass[64] = "";
char telegramBotToken[80] = "";
char telegramChatId[32] = "";
char deviceName[32] = "SmartFarm-ESP8266";
WiFiManagerParameter pUser("mqtt_user", "MQTT username", mqttUser,
                           sizeof(mqttUser));
WiFiManagerParameter pPass("mqtt_pass", "MQTT password", mqttPass,
                           sizeof(mqttPass));
WiFiManagerParameter pOta("ota_pass", "OTA password", otaPass, sizeof(otaPass));
WiFiManagerParameter pTelegramToken("telegram_bot_token", "Telegram bot token",
                                    telegramBotToken, sizeof(telegramBotToken));
WiFiManagerParameter pTelegramChat("telegram_chat_id", "Telegram chat ID",
                                   telegramChatId, sizeof(telegramChatId));
WiFiManagerParameter pName("device_name", "Device name", deviceName,
                           sizeof(deviceName));

void normalizeMqttUsername() {
  String value = String(mqttUser);
  value.trim();
  strlcpy(mqttUser, value.c_str(), sizeof(mqttUser));
}

void buildMqttClientId(char *out, size_t outSize) {
  String name = String(deviceName);
  name.trim();
  if (!name.length()) name = "SmartFarm-ESP8266";
  snprintf(out, outSize, "%.40s-%06X", name.c_str(), ESP.getChipId());
}


String urlEncode(const String &value) {
  String out;
  out.reserve(value.length() + 16);
  const char hex[] = "0123456789ABCDEF";
  for (size_t i = 0; i < value.length(); i++) {
    uint8_t c = (uint8_t)value[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~')
      out += (char)c;
    else if (c == ' ')
      out += "%20";
    else {
      out += '%';
      out += hex[c >> 4];
      out += hex[c & 15];
    }
  }
  return out;
}

bool telegramNotifyNow(const String &message) {
  if (WiFi.status() != WL_CONNECTED || !telegramBotToken[0] ||
      !telegramChatId[0])
    return false;

  if (!mqttTrustAnchor) {
    Serial.println(F("Telegram: TLS trust anchor unavailable"));
    return false;
  }
  telegramTls.setTrustAnchors(mqttTrustAnchor);
  telegramTls.setBufferSizes(4096, 512);
  // Keep Telegram notifications bounded so they cannot starve MQTT keep-alives.
  telegramTls.setTimeout(5000);
  String url = String("https://api.telegram.org/bot") + telegramBotToken +
               "/sendMessage";
  String body = String("chat_id=") + urlEncode(telegramChatId) + "&text=" +
                urlEncode(String("[SmartFarm ") + deviceName + "]\n" + message);

  for (uint8_t attempt = 1; attempt <= 1; ++attempt) {
    HTTPClient http;
    http.setTimeout(5000);
    http.setReuse(false);
    http.useHTTP10(true);
    if (!http.begin(telegramTls, url)) {
      Serial.printf("Telegram: HTTPS begin failed attempt %u, heap=%u\n",
                    attempt, ESP.getFreeHeap());
      continue;
    }

    http.addHeader("Content-Type", "application/x-www-form-urlencoded");
    int code = http.POST(body);
    String response = http.getString();
    if (code >= 200 && code < 300) {
      Serial.printf("Telegram: sent OK HTTP %d\n", code);
      http.end();
      return true;
    }

    Serial.printf("Telegram: send failed HTTP %d (%s), attempt %u, heap=%u\n",
                  code, HTTPClient::errorToString(code).c_str(), attempt,
                  ESP.getFreeHeap());
    if (response.length()) {
      response.replace("\\r", "");
      response.replace("\\n", " ");
      if (response.length() > 180)
        response.remove(180);
      Serial.printf("Telegram response: %s\n", response.c_str());
    }
    http.end();
  }
  return false;
}

static const uint8_t REMINDER_COUNT = 8;
struct CropReminder {
  bool enabled;
  bool done;
  uint8_t leadDays;
  uint8_t repeatEveryDays;
  char id[32];
  char title[72];
  char dueDate[11];
  char note[128];
  char plotId[32];
  char lastSentDate[11];
};
CropReminder reminders[REMINDER_COUNT] = {};
bool reminderQueued[REMINDER_COUNT] = {};

// Relay, Wi-Fi, MQTT, reminder, and test events are all queued so a Telegram
// HTTPS request never runs inside an MQTT callback.
enum TelegramQueueKind : uint8_t {
  TELEGRAM_QUEUE_EVENT = 0,
  TELEGRAM_QUEUE_TEST,
  TELEGRAM_QUEUE_REMINDER_TEST,
  TELEGRAM_QUEUE_REMINDER
};
struct TelegramQueueItem {
  String message;
  uint8_t attempts;
  TelegramQueueKind kind;
  int8_t reminderIndex;
  char reminderDate[11];
  bool recurring;
};
static const uint8_t TELEGRAM_QUEUE_SIZE = 4;
TelegramQueueItem telegramQueue[TELEGRAM_QUEUE_SIZE];
uint8_t telegramQueueHead = 0, telegramQueueTail = 0, telegramQueueCount = 0;
uint32_t lastTelegramAttempt = 0;

bool queueTelegram(const String &message, TelegramQueueKind kind = TELEGRAM_QUEUE_EVENT,
                   int8_t reminderIndex = -1, const String &reminderDate = String(),
                   bool recurring = false) {
  if (!telegramBotToken[0] || !telegramChatId[0] || !message.length())
    return false;
  if (telegramQueueCount >= TELEGRAM_QUEUE_SIZE) {
    Serial.println(F("Telegram queue full; dropping non-critical event"));
    return false;
  }
  telegramQueue[telegramQueueTail].message = message;
  telegramQueue[telegramQueueTail].attempts = 0;
  telegramQueue[telegramQueueTail].kind = kind;
  telegramQueue[telegramQueueTail].reminderIndex = reminderIndex;
  strlcpy(telegramQueue[telegramQueueTail].reminderDate,
          reminderDate.c_str(), sizeof(telegramQueue[telegramQueueTail].reminderDate));
  telegramQueue[telegramQueueTail].recurring = recurring;
  telegramQueueTail = (telegramQueueTail + 1) % TELEGRAM_QUEUE_SIZE;
  telegramQueueCount++;
  return true;
}

bool queueReminderTelegram(const String &message, uint8_t index,
                           const String &today, bool recurring) {
  if (index >= REMINDER_COUNT || reminderQueued[index])
    return false;
  if (!queueTelegram(message, TELEGRAM_QUEUE_REMINDER, (int8_t)index, today,
                     recurring))
    return false;
  reminderQueued[index] = true;
  return true;
}

void finishTelegramQueueItem(const TelegramQueueItem &item, bool sent);

void processTelegramQueue() {
  if (otaUpdateInProgress || !telegramQueueCount ||
      WiFi.status() != WL_CONNECTED || !telegramBotToken[0] ||
      !telegramChatId[0])
    return;
  if ((uint32_t)(millis() - lastTelegramAttempt) < 15000UL)
    return;
  lastTelegramAttempt = millis();
  TelegramQueueItem &item = telegramQueue[telegramQueueHead];
  bool sent = telegramNotifyNow(item.message);
  if (sent || ++item.attempts >= 2) {
    TelegramQueueItem completed = item;
    item.message = "";
    item.attempts = 0;
    telegramQueueHead = (telegramQueueHead + 1) % TELEGRAM_QUEUE_SIZE;
    telegramQueueCount--;
    finishTelegramQueueItem(completed, sent);
  }
}

void reportWifiState() {
  bool connected = WiFi.status() == WL_CONNECTED;
  if (!wifiStateKnown) {
    wifiStateKnown = true;
    lastWifiConnected = connected;
    return;
  }
  if (connected == lastWifiConnected)
    return;
  lastWifiConnected = connected;
  if (connected) {
    Serial.print(F("WiFi: reconnected, IP: "));
    Serial.println(WiFi.localIP());
    queueTelegram(String("WiFi กลับมาเชื่อมต่อสำเร็จ IP=") +
                  WiFi.localIP().toString());
  } else {
    Serial.println(F("WiFi: disconnected"));
    // Drop stale MQTT/TLS state immediately. The next Wi-Fi recovery can
    // establish a clean TLS session instead of reusing a broken socket.
    mqtt.disconnect();
    tls.stop();
    lastMqttAttempt = millis() - MQTT_RECONNECT_MS;
  }
}

void maintainWifi() {
  if (WiFi.status() == WL_CONNECTED)
    return;
  if ((uint32_t)(millis() - lastWifiReconnect) < WIFI_RECONNECT_INTERVAL_MS)
    return;
  lastWifiReconnect = millis();
  wifiReconnectRequests++;
  Serial.println(F("WiFi: reconnect requested"));
  WiFi.reconnect();
}

struct ScheduleSlot {
  bool enabled;
  uint8_t onH, onM, offH, offM;
};
static const uint8_t RELAY_COUNT = 4, SLOT_COUNT = 4;
ScheduleSlot schedules[RELAY_COUNT][SLOT_COUNT] = {};

bool reminderEnabled = true;
bool reminderRepeatDaily = false;
uint8_t reminderQuietStartHour = 22;
uint8_t reminderQuietStartMinute = 0;
uint8_t reminderQuietEndHour = 7;
uint8_t reminderQuietEndMinute = 0;
uint8_t reminderDefaultLeadDays = 1;
uint8_t reminderHour = 18;
uint8_t reminderMinute = 0;
uint32_t lastReminderCheck = 0;

const uint8_t relayPins[RELAY_COUNT] = {RELAY_PUMP, RELAY_ZONE1,
                                        RELAY_LIGHT_HOME, RELAY_LIGHT_SALA};
const char *relayNames[RELAY_COUNT] = {"pump", "zone1", "lighthome",
                                       "lightsala"};
uint32_t pumpStartedAt = 0;
bool pumpSafetyLatched = false;
bool emergencyLock = false;
uint32_t emergencyTimestamp = 0;
char emergencySource[24] = "";

bool relaySet(uint8_t i, bool on);
void publishRelayStatus(uint8_t i);
void publishEmergencyStatus();
void publishModeStatus();
void publishSystemError(const char *code, const char *message);
void publishTimeStatus();
bool relayHasSchedule(uint8_t r);
bool readRtcNow(DateTime &value);
bool scheduleClockMinutes(uint16_t &minutes);
bool relayScheduleDesired(uint8_t r, uint16_t now);

bool validHM(uint8_t h, uint8_t m) { return h < 24 && m < 60; }
bool parseHM(const char *s, uint8_t &h, uint8_t &m) {
  if (!s || strlen(s) != 5 || s[2] != ':' || s[0] < '0' || s[0] > '9' ||
      s[1] < '0' || s[1] > '9' || s[3] < '0' || s[3] > '9' ||
      s[4] < '0' || s[4] > '9')
    return false;
  uint8_t parsedH = (uint8_t)((s[0] - '0') * 10 + (s[1] - '0'));
  uint8_t parsedM = (uint8_t)((s[3] - '0') * 10 + (s[4] - '0'));
  if (!validHM(parsedH, parsedM)) return false;
  h = parsedH;
  m = parsedM;
  return true;
}
int relayIndex(const String &n) {
  for (int i = 0; i < RELAY_COUNT; i++)
    if (n == relayNames[i])
      return i;
  return -1;
}
bool slotIsOn(bool enabled, uint8_t onH, uint8_t onM, uint8_t offH,
              uint8_t offM, uint16_t now) {
  if (!enabled || !validHM(onH, onM) || !validHM(offH, offM))
    return false;
  uint16_t on = onH * 60U + onM, off = offH * 60U + offM;
  if (on == off)
    return false;
  return on < off ? (now >= on && now < off) : (now >= on || now < off);
}
bool relayHasSchedule(uint8_t r) {
  if (r >= RELAY_COUNT) return false;
  for (uint8_t s = 0; s < SLOT_COUNT; s++)
    if (schedules[r][s].enabled) return true;
  return false;
}
bool schedulesOverlap(const ScheduleSlot &a, const ScheduleSlot &b) {
  if (!a.enabled || !b.enabled) return false;
  for (uint16_t minute = 0; minute < 1440; minute++) {
    if (slotIsOn(a.enabled, a.onH, a.onM, a.offH, a.offM, minute) &&
        slotIsOn(b.enabled, b.onH, b.onM, b.offH, b.offM, minute))
      return true;
  }
  return false;
}
bool scheduleSetValid(const ScheduleSlot *candidate) {
  for (uint8_t i = 0; i < SLOT_COUNT; i++) {
    if (candidate[i].enabled &&
        (!validHM(candidate[i].onH, candidate[i].onM) ||
         !validHM(candidate[i].offH, candidate[i].offM) ||
         (candidate[i].onH == candidate[i].offH && candidate[i].onM == candidate[i].offM)))
      return false;
    for (uint8_t j = i + 1; j < SLOT_COUNT; j++)
      if (schedulesOverlap(candidate[i], candidate[j])) return false;
  }
  return true;
}
bool validRtcDateTime(const DateTime &value) {
  return value.isValid() && value.year() >= 2024 && value.year() <= 2099;
}
bool readRtcNow(DateTime &value) {
  if (!rtcAvailable) {
    rtcTimeValid = false;
    return false;
  }
  DateTime candidate = rtc.now();
  if (!validRtcDateTime(candidate)) {
    rtcTimeValid = false;
    return false;
  }
  value = candidate;
  rtcTimeValid = true;
  return true;
}
bool clockIsValid() {
  if (rtcAvailable && rtcTimeValid) {
    DateTime checked(2000, 1, 1);
    if (readRtcNow(checked)) return true;
  }
  return ntpTimeValid && ntp.getEpochTime() >= MIN_VALID_EPOCH;
}
bool scheduleClockMinutes(uint16_t &minutes) {
  DateTime rtcNow(2000, 1, 1);
  if (readRtcNow(rtcNow)) {
    minutes = rtcNow.hour() * 60U + rtcNow.minute();
    return true;
  }
  // A missing or power-lost DS3231 must not disable schedules when NTP is valid.
  // NTPClient already applies TZ_OFFSET_SECONDS to getHours/getMinutes.
  if (!ntpTimeValid || ntp.getEpochTime() < MIN_VALID_EPOCH) return false;
  minutes = ntp.getHours() * 60U + ntp.getMinutes();
  return true;
}
bool relayScheduleDesired(uint8_t r, uint16_t now) {
  if (r >= RELAY_COUNT)
    return false;
  for (uint8_t s = 0; s < SLOT_COUNT; s++) {
    ScheduleSlot &slot = schedules[r][s];
    if (slotIsOn(slot.enabled, slot.onH, slot.onM, slot.offH, slot.offM, now))
      return true;
  }
  return false;
}
bool relayOn(uint8_t i) {
  return i < RELAY_COUNT && digitalRead(relayPins[i]) == RELAY_ON;
}

void relaySetRaw(uint8_t i, bool on) {
  if (i >= RELAY_COUNT)
    return;
  bool wasOn = relayOn(i);
  if (wasOn == on)
    return;
  digitalWrite(relayPins[i], on ? RELAY_ON : RELAY_OFF);
  if (i == 0) {
    if (on && !pumpStartedAt)
      pumpStartedAt = millis();
    if (!on) {
      pumpStartedAt = 0;
    }
  }
  if (wasOn != on)
    queueTelegram(String("รีเลย์ ") + relayNames[i] + (on ? " เปิด" : " ปิด"));
}

void enterOtaSafeState() {
  otaUpdateInProgress = true;
  otaFailureLock = false;
  otaProgressPercent = 0;
  otaStartedAt = millis();
  otaLastProgressAt = millis();

  // OTA gets priority over MQTT/Telegram and all physical loads are forced
  // OFF before flash writing begins.
  mqtt.disconnect();
  tls.stop();
  telegramTls.stop();

  for (uint8_t i = 0; i < RELAY_COUNT; i++) {
    digitalWrite(relayPins[i], RELAY_OFF);
  }
  pumpStartedAt = 0;
  pumpSafetyLatched = false;
  Serial.println(F("OTA: SAFE STATE - all relays OFF, MQTT disconnected"));
}

void leaveOtaSafeState() {
  otaUpdateInProgress = false;
  otaFailureLock = true;
  otaProgressPercent = 0;
  otaStartedAt = 0;
  otaLastProgressAt = 0;
  pumpSafetyLatched = false;
  // Do not immediately recreate MQTT/TLS after an aborted/failed upload.
  lastMqttAttempt = millis();
  Serial.println(F("OTA: failed/aborted; relay lock active, restart required"));
}

bool relaySet(uint8_t i, bool on) {
  if (i >= RELAY_COUNT)
    return false;
  if (on && emergencyLock) {
    publishSystemError("RELAY_BLOCKED", "Emergency Stop active");
    Serial.printf("MQTT RELAY: rejected relay=%s reason=emergency-lock\n", relayNames[i]);
    return false;
  }
  if (on && otaUpdateInProgress) {
    publishSystemError("RELAY_BLOCKED", "OTA update in progress");
    Serial.printf("MQTT RELAY: rejected relay=%s reason=ota-update\n", relayNames[i]);
    return false;
  }
  if (on && otaFailureLock) {
    publishSystemError("RELAY_BLOCKED", "OTA failure lock active; restart required");
    Serial.printf("MQTT RELAY: rejected relay=%s reason=ota-failure-lock\n", relayNames[i]);
    return false;
  }
  if (i != 0) {
    relaySetRaw(i, on);
    return true;
  }
  if (on && pumpSafetyLatched) {
    publishSystemError("RELAY_BLOCKED", "Pump safety lock active");
    Serial.printf("MQTT RELAY: rejected relay=%s reason=pump-safety-lock\n", relayNames[i]);
    return false;
  }
  if (on) {
    if (!relayOn(0))
      pumpStartedAt = millis();
    pumpSafetyLatched = false;
    relaySetRaw(0, true);
  } else
    relaySetRaw(0, false);
  return true;
}

void initFS() {
  fsReady = LittleFS.begin();
  if (!fsReady)
    Serial.println(F("LittleFS unavailable"));
}
bool loadSecrets() {
  if (!fsReady || !LittleFS.exists("/smartfarm_secrets.json"))
    return false;
  File f = LittleFS.open("/smartfarm_secrets.json", "r");
  if (!f)
    return false;
  StaticJsonDocument<640> d;
  DeserializationError e = deserializeJson(d, f);
  f.close();
  if (e)
    return false;
  strlcpy(mqttUser, d["mqttUser"] | "", sizeof(mqttUser));
  strlcpy(mqttPass, d["mqttPass"] | "", sizeof(mqttPass));
  strlcpy(otaPass, d["otaPass"] | "", sizeof(otaPass));
  strlcpy(telegramBotToken, d["telegramBotToken"] | "",
          sizeof(telegramBotToken));
  strlcpy(telegramChatId, d["telegramChatId"] | "", sizeof(telegramChatId));
  strlcpy(deviceName, d["deviceName"] | "SmartFarm-ESP8266",
          sizeof(deviceName));
  return true;
}
bool saveSecrets() {
  if (!fsReady)
    return false;
  StaticJsonDocument<640> d;
  d["mqttUser"] = mqttUser;
  d["mqttPass"] = mqttPass;
  d["otaPass"] = otaPass;
  d["telegramBotToken"] = telegramBotToken;
  d["telegramChatId"] = telegramChatId;
  d["deviceName"] = deviceName;
  if (d.overflowed()) return false;
  File f = LittleFS.open("/smartfarm_secrets.json", "w");
  if (!f) return false;
  size_t bytes = serializeJson(d, f);
  f.flush();
  f.close();
  return bytes > 0;
}
void clearSchedules() {
  for (uint8_t r = 0; r < RELAY_COUNT; r++)
    for (uint8_t s = 0; s < SLOT_COUNT; s++)
      schedules[r][s] = {false, 0, 0, 0, 0};
}
void loadConfig() {
  clearSchedules();
  if (!fsReady || !LittleFS.exists("/smartfarm.json"))
    return;
  File f = LittleFS.open("/smartfarm.json", "r");
  if (!f)
    return;
  StaticJsonDocument<1536> d;
  DeserializationError e = deserializeJson(d, f);
  f.close();
  if (e) {
    Serial.println(F("Config JSON invalid - using defaults"));
    return;
  }
  JsonArray all = d["s"].as<JsonArray>();
  if (all.isNull())
    return;
  for (uint8_t r = 0; r < RELAY_COUNT && r < all.size(); r++) {
    JsonArray rs = all[r].as<JsonArray>();
    if (rs.isNull()) continue;
    ScheduleSlot candidate[SLOT_COUNT] = {};
    bool malformed = false;
    for (uint8_t s = 0; s < SLOT_COUNT && s < rs.size(); s++) {
      JsonObject o = rs[s].as<JsonObject>();
      bool enabled = o["enabled"] | false;
      uint8_t oh = o["onH"] | 0, om = o["onM"] | 0, fh = o["offH"] | 0,
              fm = o["offM"] | 0;
      if (!enabled) continue;
      if (!validHM(oh, om) || !validHM(fh, fm) || (oh == fh && om == fm)) {
        malformed = true;
        break;
      }
      candidate[s] = {true, oh, om, fh, fm};
    }
    if (!malformed && scheduleSetValid(candidate)) {
      for (uint8_t s = 0; s < SLOT_COUNT; s++) schedules[r][s] = candidate[s];
    } else {
      Serial.printf("Schedule: invalid stored data rejected relay=%s reason=%s\n",
                    relayNames[r], malformed ? "time" : "overlap");
    }
  }
}
bool saveConfig() {
  if (!fsReady)
    return false;
  StaticJsonDocument<1536> d;
  JsonArray all = d.createNestedArray("s");
  for (uint8_t r = 0; r < RELAY_COUNT; r++) {
    JsonArray rs = all.createNestedArray();
    for (uint8_t s = 0; s < SLOT_COUNT; s++) {
      JsonObject o = rs.createNestedObject();
      o["enabled"] = schedules[r][s].enabled;
      o["onH"] = schedules[r][s].onH;
      o["onM"] = schedules[r][s].onM;
      o["offH"] = schedules[r][s].offH;
      o["offM"] = schedules[r][s].offM;
    }
  }
  if (d.overflowed()) {
    Serial.println(F("Schedule: config document overflow"));
    return false;
  }
  File f = LittleFS.open("/smartfarm.json", "w");
  if (!f) {
    Serial.println(F("Schedule: cannot open config for write"));
    return false;
  }
  size_t bytes = serializeJson(d, f);
  f.flush();
  f.close();
  if (!bytes) {
    Serial.println(F("Schedule: config write returned zero bytes"));
    return false;
  }
  return true;
}

int clampInt(int value, int minimum, int maximum, int fallback) {
  if (value < minimum || value > maximum)
    return fallback;
  return value;
}

bool validDateString(const char *value) {
  int y, m, day;
  if (!value || sscanf(value, "%d-%d-%d", &y, &m, &day) != 3)
    return false;
  DateTime date(y, m, day);
  return date.isValid();
}
String formatDateSafe(uint16_t year, uint8_t month, uint8_t day) {
  char out[12];
  const unsigned y = (unsigned)(year % 10000U);
  const unsigned m = (unsigned)(month % 100U);
  const unsigned d = (unsigned)(day % 100U);
  snprintf(out, sizeof(out), "%04u-%02u-%02u", y, m, d);
  return String(out);
}

String formatLocalIsoSafe(uint32_t year, uint32_t month, uint32_t day,
                          uint32_t hour, uint32_t minute, uint32_t second) {
  char out[32];
  const unsigned y = (unsigned)(year % 10000U);
  const unsigned mo = (unsigned)(month % 100U);
  const unsigned d = (unsigned)(day % 100U);
  const unsigned h = (unsigned)(hour % 100U);
  const unsigned mi = (unsigned)(minute % 100U);
  const unsigned s = (unsigned)(second % 100U);
  snprintf(out, sizeof(out), "%04u-%02u-%02uT%02u:%02u:%02u+07:00",
           y, mo, d, h, mi, s);
  return String(out);
}

String currentDateString() {
  DateTime now(2000, 1, 1);
  if (readRtcNow(now)) return formatDateSafe(now.year(), now.month(), now.day());
  uint32_t epoch = ntp.getEpochTime();
  if (!ntpTimeValid || epoch < MIN_VALID_EPOCH)
    return String();
  DateTime fallbackNow(epoch);
  return formatDateSafe(fallbackNow.year(), fallbackNow.month(), fallbackNow.day());
}

int dateDeltaDays(const char *target, const String &today) {
  if (!validDateString(target) || !validDateString(today.c_str()))
    return 9999;
  int ty, tm, td, yy, ym, yd;
  if (sscanf(target, "%d-%d-%d", &ty, &tm, &td) != 3 ||
      sscanf(today.c_str(), "%d-%d-%d", &yy, &ym, &yd) != 3)
    return 9999;
  DateTime targetDate(ty, tm, td), todayDate(yy, ym, yd);
  return (int)((targetDate.unixtime() - todayDate.unixtime()) / 86400L);
}

int findReminder(const char *id) {
  if (!id || !id[0])
    return -1;
  for (uint8_t i = 0; i < REMINDER_COUNT; i++)
    if (reminders[i].id[0] && strcmp(reminders[i].id, id) == 0)
      return i;
  return -1;
}

int findEmptyReminder() {
  for (uint8_t i = 0; i < REMINDER_COUNT; i++)
    if (!reminders[i].enabled && !reminders[i].id[0])
      return i;
  return -1;
}

void clearReminders() {
  for (uint8_t i = 0; i < REMINDER_COUNT; i++)
    reminders[i] = {};
}

void loadReminders() {
  clearReminders();
  reminderEnabled = true;
  reminderRepeatDaily = false;
  reminderQuietStartHour = 22;
  reminderQuietStartMinute = 0;
  reminderQuietEndHour = 7;
  reminderQuietEndMinute = 0;
  reminderDefaultLeadDays = 1;
  reminderHour = 18;
  reminderMinute = 0;
  if (!fsReady || !LittleFS.exists("/smartfarm_reminders.json"))
    return;
  File f = LittleFS.open("/smartfarm_reminders.json", "r");
  if (!f)
    return;
  DynamicJsonDocument d(4096);
  DeserializationError e = deserializeJson(d, f);
  f.close();
  if (e)
    return;
  reminderEnabled = d["enabled"] | true;
  reminderRepeatDaily = d["repeatDaily"] | false;
  reminderQuietStartHour = clampInt(d["quietStartHour"] | 22, 0, 23, 22);
  reminderQuietStartMinute = clampInt(d["quietStartMinute"] | 0, 0, 59, 0);
  reminderQuietEndHour = clampInt(d["quietEndHour"] | 7, 0, 23, 7);
  reminderQuietEndMinute = clampInt(d["quietEndMinute"] | 0, 0, 59, 0);
  reminderDefaultLeadDays = clampInt(d["leadDays"] | 1, 0, 7, 1);
  reminderHour = clampInt(d["hour"] | 18, 0, 23, 18);
  reminderMinute = clampInt(d["minute"] | 0, 0, 59, 0);
  JsonArray items = d["items"].as<JsonArray>();
  if (items.isNull())
    return;
  uint8_t index = 0;
  for (JsonObject item : items) {
    if (index >= REMINDER_COUNT)
      break;
    const char *id = item["id"] | "";
    const char *title = item["title"] | "";
    const char *due = item["due"] | "";
    if (!id[0] || !title[0] || !validDateString(due))
      continue;
    CropReminder &reminder = reminders[index++];
    reminder.enabled = item["enabled"] | true;
    reminder.done = item["done"] | false;
    reminder.repeatEveryDays = clampInt(item["repeatEveryDays"] | 0, 0, 30, 0);
    reminder.leadDays = clampInt(item["leadDays"] | reminderDefaultLeadDays, 0, 7, reminderDefaultLeadDays);
    strlcpy(reminder.id, id, sizeof(reminder.id));
    strlcpy(reminder.title, title, sizeof(reminder.title));
    strlcpy(reminder.dueDate, due, sizeof(reminder.dueDate));
    strlcpy(reminder.note, item["note"] | "", sizeof(reminder.note));
    strlcpy(reminder.plotId, item["plotId"] | "", sizeof(reminder.plotId));
    strlcpy(reminder.lastSentDate, item["lastSentDate"] | "",
            sizeof(reminder.lastSentDate));
  }
}

void saveReminders() {
  if (!fsReady)
    return;
  DynamicJsonDocument d(4096);
  d["enabled"] = reminderEnabled;
  d["repeatDaily"] = reminderRepeatDaily;
  d["quietStartHour"] = reminderQuietStartHour;
  d["quietStartMinute"] = reminderQuietStartMinute;
  d["quietEndHour"] = reminderQuietEndHour;
  d["quietEndMinute"] = reminderQuietEndMinute;
  d["leadDays"] = reminderDefaultLeadDays;
  d["hour"] = reminderHour;
  d["minute"] = reminderMinute;
  JsonArray items = d.createNestedArray("items");
  for (uint8_t i = 0; i < REMINDER_COUNT; i++) {
    if (!reminders[i].id[0])
      continue;
    JsonObject item = items.createNestedObject();
    item["enabled"] = reminders[i].enabled;
    item["done"] = reminders[i].done;
    item["repeatEveryDays"] = reminders[i].repeatEveryDays;
    item["leadDays"] = reminders[i].leadDays;
    item["id"] = reminders[i].id;
    item["title"] = reminders[i].title;
    item["due"] = reminders[i].dueDate;
    item["note"] = reminders[i].note;
    item["plotId"] = reminders[i].plotId;
    item["lastSentDate"] = reminders[i].lastSentDate;
  }
  File f = LittleFS.open("/smartfarm_reminders.json", "w");
  if (f) {
    serializeJson(d, f);
    f.close();
  }
}

void publishReminderStatus(const char *event, int index = -1,
                           const String &detail = String()) {
  if (!mqtt.connected())
    return;
  StaticJsonDocument<768> d;
  d["event"] = event ? event : "status";
  d["enabled"] = reminderEnabled;
  d["repeatDaily"] = reminderRepeatDaily;
  d["quietStartHour"] = reminderQuietStartHour;
  d["quietStartMinute"] = reminderQuietStartMinute;
  d["quietEndHour"] = reminderQuietEndHour;
  d["quietEndMinute"] = reminderQuietEndMinute;
  d["leadDays"] = reminderDefaultLeadDays;
  d["hour"] = reminderHour;
  d["minute"] = reminderMinute;
  if (index >= 0 && index < REMINDER_COUNT) {
    CropReminder &reminder = reminders[index];
    d["id"] = reminder.id;
    d["done"] = reminder.done;
    d["taskEnabled"] = reminder.enabled;
    d["due"] = reminder.dueDate;
    d["repeatEveryDays"] = reminder.repeatEveryDays;
    d["plotId"] = reminder.plotId;
    d["lastSentDate"] = reminder.lastSentDate;
  }
  if (detail.length())
    d["detail"] = detail;
  char out[768];
  serializeJson(d, out, sizeof(out));
  mqtt.publish(MQTT_BASE "/reminder/status", out, true);
}

String reminderDateAfterDays(const char *value, int days);

void finishTelegramQueueItem(const TelegramQueueItem &item, bool sent) {
  if (item.kind == TELEGRAM_QUEUE_REMINDER_TEST) {
    publishReminderStatus(sent ? "test_sent" : "test_failed");
    return;
  }
  if (item.kind != TELEGRAM_QUEUE_REMINDER || item.reminderIndex < 0 ||
      item.reminderIndex >= REMINDER_COUNT)
    return;

  uint8_t index = (uint8_t)item.reminderIndex;
  reminderQueued[index] = false;
  CropReminder &reminder = reminders[index];
  if (!sent) {
    publishReminderStatus("send_failed", index);
    return;
  }
  if (item.recurring) {
    String nextDue = reminderDateAfterDays(reminder.dueDate, reminder.repeatEveryDays);
    strlcpy(reminder.dueDate, nextDue.c_str(), sizeof(reminder.dueDate));
    reminder.lastSentDate[0] = '\0';
  } else {
    strlcpy(reminder.lastSentDate, item.reminderDate,
            sizeof(reminder.lastSentDate));
  }
  saveReminders();
  publishReminderStatus(item.recurring ? "sent_recurring" : "sent", index);
}

bool handleReminderMessage(const String &message) {
  StaticJsonDocument<768> d;
  if (deserializeJson(d, message))
    return false;
  const char *op = d["op"] | "";
  if (strcmp(op, "settings") == 0) {
    reminderEnabled = d["enabled"] | true;
    reminderRepeatDaily = d["repeatDaily"] | false;
    reminderQuietStartHour = clampInt(d["quietStartHour"] | 22, 0, 23, 22);
    reminderQuietStartMinute = clampInt(d["quietStartMinute"] | 0, 0, 59, 0);
    reminderQuietEndHour = clampInt(d["quietEndHour"] | 7, 0, 23, 7);
    reminderQuietEndMinute = clampInt(d["quietEndMinute"] | 0, 0, 59, 0);
    reminderDefaultLeadDays = clampInt(d["leadDays"] | 1, 0, 7, 1);
    reminderHour = clampInt(d["hour"] | 18, 0, 23, 18);
    reminderMinute = clampInt(d["minute"] | 0, 0, 59, 0);
    saveReminders();
    publishReminderStatus("settings");
    return true;
  }
  if (strcmp(op, "sync") == 0) {
    publishReminderStatus("sync");
    return true;
  }
  if (strcmp(op, "test") == 0) {
    bool queued = queueTelegram(F("ทดสอบ Telegram reminder จาก ESP8266 สำเร็จ"),
                                TELEGRAM_QUEUE_REMINDER_TEST);
    publishReminderStatus(queued ? "test_queued" : "test_not_queued");
    return queued;
  }

  const char *id = d["id"] | "";
  int index = findReminder(id);
  if (strcmp(op, "delete") == 0) {
    if (index < 0)
      return false;
    reminders[index] = {};
    saveReminders();
    publishReminderStatus("delete", -1, String(id));
    return true;
  }
  if (strcmp(op, "done") == 0) {
    if (index < 0)
      return false;
    reminders[index].done = d["done"] | true;
    saveReminders();
    publishReminderStatus("done", index);
    return true;
  }
  if (strcmp(op, "snooze") == 0) {
    const char *due = d["due"] | "";
    if (index < 0 || !validDateString(due))
      return false;
    strlcpy(reminders[index].dueDate, due, sizeof(reminders[index].dueDate));
    reminders[index].done = false;
    reminders[index].lastSentDate[0] = '\0';
    saveReminders();
    publishReminderStatus("snooze", index);
    return true;
  }
  if (strcmp(op, "upsert") != 0)
    return false;

  const char *title = d["title"] | "";
  const char *due = d["due"] | "";
  if (!id[0] || !title[0] || !validDateString(due))
    return false;
  if (index < 0)
    index = findEmptyReminder();
  if (index < 0)
    return false;
  CropReminder &reminder = reminders[index];
    uint8_t nextRepeatEveryDays = clampInt(d["repeatEveryDays"] | 0, 0, 30, 0);
  const char *nextPlotId = d["plotId"] | "";
  bool changed = strcmp(reminder.title, title) != 0 ||
                 strcmp(reminder.dueDate, due) != 0 ||
                 strcmp(reminder.plotId, nextPlotId) != 0 ||
                 reminder.repeatEveryDays != nextRepeatEveryDays ||
                 reminder.leadDays !=
                     clampInt(d["leadDays"] | reminderDefaultLeadDays, 0, 7, reminderDefaultLeadDays);
  reminder.enabled = d["enabled"] | true;
  reminder.done = d["done"] | false;
  reminder.repeatEveryDays = nextRepeatEveryDays;
  reminder.leadDays = clampInt(d["leadDays"] | reminderDefaultLeadDays, 0, 7, reminderDefaultLeadDays);

  strlcpy(reminder.id, id, sizeof(reminder.id));
  strlcpy(reminder.title, title, sizeof(reminder.title));
  strlcpy(reminder.dueDate, due, sizeof(reminder.dueDate));
  strlcpy(reminder.note, d["note"] | "", sizeof(reminder.note));
  strlcpy(reminder.plotId, nextPlotId, sizeof(reminder.plotId));
  if (changed)
    reminder.lastSentDate[0] = '\0';
  saveReminders();
  publishReminderStatus("upsert", index);
  return true;
}

String reminderDateAfterDays(const char *value, int days) {
  if (!validDateString(value))
    return String(value ? value : "");
  int year = 0, month = 0, day = 0;
  if (sscanf(value, "%d-%d-%d", &year, &month, &day) != 3)
    return String(value);
  DateTime next((uint32_t)(DateTime(year, month, day).unixtime() + (int32_t)days * 86400L));
  return formatDateSafe(next.year(), next.month(), next.day());
}

bool reminderInQuietHours() {
  uint16_t now = currentMinutes();
  uint16_t start = reminderQuietStartHour * 60U + reminderQuietStartMinute;
  uint16_t end = reminderQuietEndHour * 60U + reminderQuietEndMinute;
  if (start == end)
    return false;
  return start < end ? (now >= start && now < end) : (now >= start || now < end);
}

void runReminderTask(uint8_t index, const String &today, bool overdue) {
  CropReminder &reminder = reminders[index];
  String message = overdue ? "งานรอบปลูกเลยกำหนดแล้ว" : "แจ้งเตือนงานรอบปลูกล่วงหน้า";
  message += "\n\n";
  message += overdue ? "งาน: " : "กำหนด: ";
  message += reminder.title;
  if (reminder.plotId[0]) {
    message += "\nแปลง: ";
    message += reminder.plotId;
  }
  message += "\nครบกำหนด: ";
  message += reminder.dueDate;
  if (reminder.repeatEveryDays > 0) {
    message += "\nทำซ้ำทุก ";
    message += reminder.repeatEveryDays;
    message += " วัน";
  }
  if (reminder.note[0]) {
    message += "\nรายละเอียด: ";
    message += reminder.note;
  }
  if (queueReminderTelegram(message, index, today,
                            reminder.repeatEveryDays > 0)) {
    publishReminderStatus("queued", index);
  } else {
    publishReminderStatus("not_queued", index);
  }
}

void runReminders() {
  if ((uint32_t)(millis() - lastReminderCheck) < 30000UL)
    return;
  lastReminderCheck = millis();
  if (!reminderEnabled || !clockIsValid())
    return;
  if (reminderInQuietHours())
    return;
  String today = currentDateString();
  if (!validDateString(today.c_str()))
    return;
  uint16_t now = currentMinutes();
  uint16_t reminderAt = reminderHour * 60U + reminderMinute;
  for (uint8_t i = 0; i < REMINDER_COUNT; i++) {
    CropReminder &reminder = reminders[i];
    if (!reminder.enabled || reminder.done || !reminder.id[0] ||
        !validDateString(reminder.dueDate))
      continue;
    int delta = dateDeltaDays(reminder.dueDate, today);
    bool overdue = delta < 0 && reminderRepeatDaily;
    bool dueForReminder = delta == reminder.leadDays;
    if ((!dueForReminder && !overdue) || now < reminderAt ||
        strcmp(reminder.lastSentDate, today.c_str()) == 0)
      continue;
    runReminderTask(i, today, overdue);
  }
}

uint16_t currentMinutes() {
  DateTime now(2000, 1, 1);
  if (readRtcNow(now)) return now.hour() * 60U + now.minute();
  if (!ntpTimeValid || ntp.getEpochTime() < MIN_VALID_EPOCH) return 0;
  return ntp.getHours() * 60U + ntp.getMinutes();
}
String rtcIso() {
  DateTime now(2000, 1, 1);
  if (!readRtcNow(now)) {
    if (!ntpTimeValid || ntp.getEpochTime() < MIN_VALID_EPOCH) return String();
    now = DateTime(ntp.getEpochTime());
  }
  return formatLocalIsoSafe(now.year(), now.month(), now.day(), now.hour(),
                            now.minute(), now.second());
}
void initRTC() {
  Wire.begin(RTC_SDA, RTC_SCL);
  delay(5);
  rtcAvailable = rtc.begin();
  if (!rtcAvailable) {
    Serial.println(F("DS3231 not found - NTP fallback"));
    return;
  }
  if (rtc.lostPower()) {
    rtcTimeValid = false;
    Serial.println(F("DS3231 lost power - waiting for NTP sync"));
  } else {
    DateTime n(2000, 1, 1);
    rtcTimeValid = readRtcNow(n);
    if (!rtcTimeValid)
      Serial.println(F("DS3231 returned invalid time - NTP fallback"));
  }
}
bool syncNTPFromInternet(bool force = false) {
  if (WiFi.status() != WL_CONNECTED) return ntpTimeValid;
  if (!force && lastNtpAttempt &&
      millis() - lastNtpAttempt < NTP_RETRY_INTERVAL_MS)
    return ntpTimeValid;
  lastNtpAttempt = millis();
  for (uint8_t i = 0; i < NTP_SERVER_COUNT; i++) {
    ntp.setPoolServerName(NTP_SERVERS[i]);
    if (ntp.forceUpdate() && ntp.getEpochTime() >= MIN_VALID_EPOCH) {
      ntpTimeValid = true;
      Serial.print(F("NTP synced from "));
      Serial.println(NTP_SERVERS[i]);
      return true;
    }
    Serial.print(F("NTP server failed: "));
    Serial.println(NTP_SERVERS[i]);
  }
  if (!ntpTimeValid) Serial.println(F("NTP unavailable - schedules paused until time is valid"));
  return ntpTimeValid;
}
void syncRTCFromNTP(bool force = false) {
  if (WiFi.status() != WL_CONNECTED) return;
  bool ntpUpdated = syncNTPFromInternet(force);
  if (!rtcAvailable || !ntpUpdated) return;
  if (!force && lastRtcSync &&
      millis() - lastRtcSync < RTC_NTP_SYNC_INTERVAL_MS)
    return;
  uint32_t localEpoch = ntp.getEpochTime();
  if (localEpoch < MIN_VALID_EPOCH) return;
  rtc.adjust(DateTime(localEpoch));
  DateTime verified(2000, 1, 1);
  bool readBackOk = readRtcNow(verified);
  uint32_t verifiedEpoch = readBackOk ? verified.unixtime() : 0;
  uint32_t delta = verifiedEpoch >= localEpoch
                       ? verifiedEpoch - localEpoch
                       : localEpoch - verifiedEpoch;
  if (readBackOk && delta <= 2UL) {
    rtcTimeValid = true;
    lastRtcSync = millis();
    Serial.println(F("RTC synced from NTP and read-back verified"));
  } else {
    rtcTimeValid = false;
    Serial.println(F("RTC sync read-back failed - NTP fallback"));
  }
}

void reportClockStatus() {
  uint32_t epoch = ntp.getEpochTime();
  Serial.print(F("NTP: epoch="));
  Serial.print(epoch);
  if (ntpTimeValid && epoch >= MIN_VALID_EPOCH) {
    Serial.println(F(" VALID"));
    return;
  }
  Serial.println(F(" INVALID/UNSYNCED"));
}

bool verifyMqttEndpoint() {
  if (!mqttTlsReady) {
    Serial.println(F("MQTT VERIFY: skipped because CA trust anchor is not configured"));
    return false;
  }
  Serial.print(F("MQTT VERIFY: DNS "));
  Serial.print(MQTT_SERVER);
  Serial.print(F(" ... "));
  IPAddress resolved;
  if (!WiFi.hostByName(MQTT_SERVER, resolved)) {
    Serial.println(F("FAILED"));
    return false;
  }
  Serial.print(F("OK ("));
  Serial.print(resolved);
  Serial.println(F(")"));

  // This is MQTT over TLS for ESP8266; the EMQX Serverless dashboard uses WSS 8084.
  // The trust anchor was installed during setup; never downgrade to insecure.
  if (!prepareTlsValidationTime()) {
    Serial.println(F("MQTT VERIFY: skipped - invalid X509 clock"));
    return false;
  }
  tls.setBufferSizes(4096, 512);
  tls.setTimeout(10);
  uint32_t started = millis();
  bool tlsOk = tls.connect(MQTT_SERVER, MQTT_PORT);
  uint32_t elapsed = millis() - started;
  if (tlsOk) {
    Serial.printf("MQTT VERIFY: TLS TCP %u OK (%lu ms)\n", MQTT_PORT,
                  (unsigned long)elapsed);
    tls.stop();
    return true;
  }
  char error[128] = "";
  int errorCode = tls.getLastSSLError(error, sizeof(error));
  Serial.printf("MQTT VERIFY: TLS TCP %u FAILED (%lu ms), ssl=%d (%s)\n",
                MQTT_PORT, (unsigned long)elapsed, errorCode, error);
  tls.stop();
  return false;
}

void diagnoseMqttTransport() {
  if ((uint32_t)(millis() - lastMqttDiagnostic) <
      MQTT_DIAGNOSTIC_INTERVAL_MS)
    return;
  lastMqttDiagnostic = millis();

  Serial.print(F("MQTT DIAG: WiFi RSSI="));
  Serial.print(WiFi.RSSI());
  Serial.print(F(" IP="));
  Serial.println(WiFi.localIP());

  verifyMqttEndpoint();
}

void publishRelayStatus(uint8_t i) {
  if (!mqtt.connected() || i >= RELAY_COUNT)
    return;
  String t = String(MQTT_BASE) + "/relay/" + relayNames[i] + "/status";
  mqtt.publish(t.c_str(), relayOn(i) ? "ON" : "OFF", true);
}
void publishScheduleStatus(uint8_t r) {
  if (!mqtt.connected() || r >= RELAY_COUNT)
    return;
  StaticJsonDocument<640> d;
  JsonArray slots = d.createNestedArray("slots");
  for (uint8_t s = 0; s < SLOT_COUNT; s++) {
    JsonObject o = slots.createNestedObject();
    o["enabled"] = schedules[r][s].enabled;
    char on[6], off[6];
    snprintf(on, sizeof(on), "%02u:%02u",
             (unsigned)(schedules[r][s].onH % 100U),
             (unsigned)(schedules[r][s].onM % 100U));
    snprintf(off, sizeof(off), "%02u:%02u",
             (unsigned)(schedules[r][s].offH % 100U),
             (unsigned)(schedules[r][s].offM % 100U));
    o["on"] = on;
    o["off"] = off;
  }
  char out[640];
  serializeJson(d, out, sizeof(out));
  String t = String(MQTT_BASE) + "/schedule/" + relayNames[r] + "/status";
  mqtt.publish(t.c_str(), out, true);
}
void publishModeStatus() {
  if (!mqtt.connected()) return;
  mqtt.publish(MQTT_BASE "/mode/status", autoMode ? "AUTO" : "MANUAL", true);
}
void publishSystemError(const char *code, const char *message) {
  if (!mqtt.connected()) return;
  StaticJsonDocument<256> d;
  d["code"] = code ? code : "UNKNOWN";
  d["message"] = message ? message : "Unknown error";
  String iso = rtcIso();
  if (iso.length()) d["timestamp"] = iso;
  char out[256];
  serializeJson(d, out, sizeof(out));
  mqtt.publish(MQTT_BASE "/system/error", out, false);
}
void publishTimeStatus() {
  if (!mqtt.connected()) return;
  String iso = rtcIso();
  if (!iso.length() && ntpTimeValid) {
    time_t epoch = ntp.getEpochTime();
    struct tm *tmv = gmtime(&epoch);
    if (tmv) {
      iso = formatLocalIsoSafe((uint32_t)(tmv->tm_year + 1900),
                               (uint32_t)(tmv->tm_mon + 1),
                               (uint32_t)tmv->tm_mday,
                               (uint32_t)tmv->tm_hour,
                               (uint32_t)tmv->tm_min,
                               (uint32_t)tmv->tm_sec);
    }
  }
  if (!iso.length()) return;
  StaticJsonDocument<192> d;
  d["date"] = iso.substring(0, 10);
  d["time"] = iso.substring(11, 19);
  d["timezone"] = "Asia/Bangkok";
  d["utc_offset"] = 7;
  char out[192];
  serializeJson(d, out, sizeof(out));
  mqtt.publish(MQTT_BASE "/time", out, false);
}
void publishEmergencyStatus() {
  if (!mqtt.connected())
    return;
  StaticJsonDocument<192> d;
  d["active"] = emergencyLock;
  d["source"] = emergencySource;
  d["timestamp"] = emergencyTimestamp / 1000UL;
  String iso = rtcIso();
  if (iso.length()) d["time"] = iso;
  char out[192];
  serializeJson(d, out, sizeof(out));
  mqtt.publish(MQTT_BASE "/emergency/status", out, true);
}
void engageEmergencyStop(const char *source) {
  emergencyLock = true;
  emergencyTimestamp = millis();
  strlcpy(emergencySource, source && source[0] ? source : "unknown", sizeof(emergencySource));
  for (uint8_t i = 0; i < RELAY_COUNT; i++) {
    relaySetRaw(i, false);
  }
  Serial.printf("EMERGENCY STOP: active source=%s\n", emergencySource);
  queueTelegram(String("หยุดฉุกเฉินทำงาน source=") + emergencySource);
  publishStatus();
}
void resetEmergencyStop(const char *source) {
  emergencyLock = false;
  emergencyTimestamp = millis();
  strlcpy(emergencySource, source && source[0] ? source : "reset", sizeof(emergencySource));
  Serial.printf("EMERGENCY STOP: reset source=%s\n", emergencySource);
  uint16_t resetMinutes;
  if (scheduleClockMinutes(resetMinutes)) applyAutoState(resetMinutes);
  publishStatus();
  queueTelegram(String("ปลดล็อกหยุดฉุกเฉิน source=") + emergencySource);
}
void publishStatus() {
  if (!mqtt.connected())
    return;
  for (uint8_t i = 0; i < RELAY_COUNT; i++) {
    publishRelayStatus(i);
    publishScheduleStatus(i);
  }
  publishEmergencyStatus();
  publishModeStatus();
  publishTimeStatus();
}
void applyAutoState(uint16_t now) {
  if (!autoMode) return;
  if (emergencyLock || otaUpdateInProgress || otaFailureLock) {
    for (uint8_t i = 0; i < RELAY_COUNT; i++) relaySetRaw(i, false);
    return;
  }
  if (!clockIsValid()) return;
  for (uint8_t i = 0; i < RELAY_COUNT; i++) {
    if (!relayHasSchedule(i)) continue;
    bool desired = relayScheduleDesired(i, now);
    if (i == 0) {
      if (!desired) {
        pumpSafetyLatched = false;
        relaySetRaw(0, false);
      } else if (!pumpSafetyLatched)
        relaySetRaw(0, true);
    } else
      relaySetRaw(i, desired);
  }
}

void openMqttSetupPortal() {
  if (mqttPortalOpened)
    return;
  mqttPortalOpened = true;
  Serial.println(F("MQTT CONFIG: opening SmartFarm_Setup portal"));
  WiFiManager wm;
  wm.setConfigPortalTimeout(WIFI_PORTAL_TIMEOUT_SECONDS);
  pUser.setValue(mqttUser, sizeof(mqttUser));
  pPass.setValue(mqttPass, sizeof(mqttPass));
  pOta.setValue(otaPass, sizeof(otaPass));
  pTelegramToken.setValue(telegramBotToken, sizeof(telegramBotToken));
  pTelegramChat.setValue(telegramChatId, sizeof(telegramChatId));
  pName.setValue(deviceName, sizeof(deviceName));
  wm.addParameter(&pUser);
  wm.addParameter(&pPass);
  wm.addParameter(&pOta);
  wm.addParameter(&pTelegramToken);
  wm.addParameter(&pTelegramChat);
  wm.addParameter(&pName);
  if (wm.startConfigPortal("SmartFarm_Setup")) {
    strlcpy(mqttUser, pUser.getValue(), sizeof(mqttUser));
    strlcpy(mqttPass, pPass.getValue(), sizeof(mqttPass));
    strlcpy(otaPass, pOta.getValue(), sizeof(otaPass));
    strlcpy(telegramBotToken, pTelegramToken.getValue(),
            sizeof(telegramBotToken));
    strlcpy(telegramChatId, pTelegramChat.getValue(), sizeof(telegramChatId));
    strlcpy(deviceName, pName.getValue(), sizeof(deviceName));
    if (saveSecrets()) {
      Serial.println(F("MQTT CONFIG: credentials saved"));
      queueTelegram(F("บันทึกการตั้งค่าอุปกรณ์และ Telegram สำเร็จ"));
    } else {
      Serial.println(F("MQTT CONFIG: credential persistence failed"));
      queueTelegram(F("บันทึก credential ไม่สำเร็จ กรุณาตรวจ LittleFS"));
    }
  } else
    Serial.println(F("MQTT CONFIG: portal timeout/failed"));
  mqttAuthFailures = 0;
  mqttConfigReported = false;
  mqttPortalOpened = false;
}

void publishTelegramStatus() {
  if (!mqtt.connected())
    return;
  StaticJsonDocument<128> d;
  d["configured"] = telegramBotToken[0] && telegramChatId[0];
  char out[128];
  serializeJson(d, out, sizeof(out));
  mqtt.publish(MQTT_BASE "/config/telegram/status", out, true);
}

bool handleTelegramConfig(const String &message) {
  StaticJsonDocument<256> d;
  if (deserializeJson(d, message))
    return false;
  const char *botToken = d["botToken"] | "";
  const char *chatId = d["chatId"] | "";
  if (!botToken[0] || !chatId[0] || strlen(botToken) >= sizeof(telegramBotToken) ||
      strlen(chatId) >= sizeof(telegramChatId))
    return false;
  char previousToken[sizeof(telegramBotToken)];
  char previousChat[sizeof(telegramChatId)];
  strlcpy(previousToken, telegramBotToken, sizeof(previousToken));
  strlcpy(previousChat, telegramChatId, sizeof(previousChat));
  strlcpy(telegramBotToken, botToken, sizeof(telegramBotToken));
  strlcpy(telegramChatId, chatId, sizeof(telegramChatId));
  if (!saveSecrets()) {
    strlcpy(telegramBotToken, previousToken, sizeof(telegramBotToken));
    strlcpy(telegramChatId, previousChat, sizeof(telegramChatId));
    publishTelegramStatus();
    Serial.println(F("Telegram CONFIG: persistence failed"));
    return false;
  }
  publishTelegramStatus();
  queueTelegram(F("บันทึกการตั้งค่า Telegram จากแดชบอร์ดสำเร็จ"));
  return true;
}

uint32_t lastAiAlertAt = 0;
String lastAiAlertId;
void publishAiAlertStatus(const char *status, const String &id = String()) {
  if (!mqtt.connected()) return;
  StaticJsonDocument<192> d;
  d["status"] = status;
  if (id.length()) d["id"] = id;
  d["at"] = millis();
  char out[192];
  serializeJson(d, out, sizeof(out));
  mqtt.publish(MQTT_BASE "/ai/alert/status", out, false);
}
bool validAiSeverity(const char *value) {
  return value && (!strcmp(value, "info") || !strcmp(value, "warning") || !strcmp(value, "critical"));
}
bool handleAiAlert(const String &message) {
  if (message.length() > 900) return false;
  StaticJsonDocument<768> d;
  if (deserializeJson(d, message)) {
    publishAiAlertStatus("rejected");
    return false;
  }
  const char *id = d["id"] | "";
  const char *severity = d["severity"] | "";
  const char *title = d["title"] | "";
  const char *text = d["message"] | "";
  if (!id[0] || strlen(id) >= 48 || !validAiSeverity(severity) || !title[0] || strlen(title) > 96 || !text[0] || strlen(text) > 420) {
    publishAiAlertStatus("rejected", String(id));
    return false;
  }
  for (const char *p = text; *p; ++p) {
    if ((uint8_t)*p < 0x09 || (*p == '\r')) {
      publishAiAlertStatus("rejected", String(id));
      return false;
    }
  }
  String alertId(id);
  if (alertId == lastAiAlertId && (uint32_t)(millis() - lastAiAlertAt) < 900000UL) {
    publishAiAlertStatus("duplicate", alertId);
    return true;
  }
  if (lastAiAlertAt && (uint32_t)(millis() - lastAiAlertAt) < 60000UL) {
    publishAiAlertStatus("rate_limited", alertId);
    return false;
  }
  String telegram = String("AI ฟาร์ม · ") + title + "\n" + text;
  if (!queueTelegram(telegram)) {
    publishAiAlertStatus("not_queued", alertId);
    return false;
  }
  lastAiAlertId = alertId;
  lastAiAlertAt = millis();
  publishAiAlertStatus("queued", alertId);
  Serial.printf("AI ALERT: queued id=%s severity=%s\n", id, severity);
  return true;
}
void mqttCallback(char *topic, byte *payload, unsigned int len) {
  String t(topic), msg;
  msg.reserve(len + 1);
  for (unsigned int i = 0; i < len; i++)
    msg += (char)payload[i];
  msg.trim();

  // Diagnostic: show every inbound control packet without blocking MQTT.
  // Limit payload logging to keep Serial output bounded on ESP8266.
  const bool sensitiveTopic =
      t == MQTT_BASE "/config/telegram/set" ||
      t == MQTT_BASE "/config/telegram/test";
  if (sensitiveTopic) {
    Serial.printf("MQTT RX: topic=%s payload=[REDACTED]\n", t.c_str());
  } else if (t.startsWith(String(MQTT_BASE) + "/relay/") ||
      t.startsWith(String(MQTT_BASE) + "/schedule/") ||
      t.startsWith(String(MQTT_BASE) + "/reminder/") ||
      t.startsWith(String(MQTT_BASE) + "/ai/alert/")) {
    String logMsg = msg;
    if (logMsg.length() > 96)
      logMsg.remove(96);
    Serial.printf("MQTT RX: topic=%s payload=%s\n", t.c_str(), logMsg.c_str());
  }

  if (t == MQTT_BASE "/mode/set") {
    if (msg.equalsIgnoreCase("AUTO")) autoMode = true;
    else if (msg.equalsIgnoreCase("MANUAL")) autoMode = false;
    else {
      publishSystemError("INVALID_COMMAND", "Invalid mode command");
      return;
    }
    publishModeStatus();
    return;
  }
  if (t == MQTT_BASE "/emergency/set") {
    if (msg.equalsIgnoreCase("STOP") || msg.equalsIgnoreCase("EMERGENCY_STOP"))
      engageEmergencyStop("mqtt");
    else if (msg.equalsIgnoreCase("RESET") || msg.equalsIgnoreCase("EMERGENCY_RESET"))
      resetEmergencyStop("mqtt");
    else
      Serial.println(F("Emergency: invalid payload"));
    return;
  }
  if (t == MQTT_BASE "/config/telegram/set") {
    if (!handleTelegramConfig(msg)) {
      Serial.println(F("Telegram CONFIG: invalid payload"));
      publishSystemError("INVALID_JSON", "Invalid Telegram configuration");
    }
    return;
  }
  if (t == MQTT_BASE "/config/telegram/test") {
    bool queued = queueTelegram(F("ทดสอบ Telegram จากแดชบอร์ดสำเร็จ"),
                                TELEGRAM_QUEUE_TEST);
    publishTelegramStatus();
    Serial.println(queued ? F("Telegram TEST: queued")
                           : F("Telegram TEST: queue full or not configured"));
    return;
  }
  if (t == MQTT_BASE "/ai/alert/set") {
    handleAiAlert(msg);
    return;
  }
  if (t == MQTT_BASE "/reminder/set") {
    if (!handleReminderMessage(msg)) {
      Serial.println(F("Reminder: invalid payload"));
      publishReminderStatus("error", -1, "invalid payload");
      publishSystemError("INVALID_JSON", "Invalid reminder payload");
    }
    return;
  }

  String rp = String(MQTT_BASE) + "/relay/";
  if (t.startsWith(rp) && t.endsWith("/set")) {
    String n = t.substring(rp.length(), t.length() - 4);
    int i = relayIndex(n);
    if (i < 0)
      return;
    bool accepted = false;
    if (msg.equalsIgnoreCase("ON"))
      accepted = relaySet((uint8_t)i, true);
    else if (msg.equalsIgnoreCase("OFF"))
      accepted = relaySet((uint8_t)i, false);
    else {
      Serial.printf("MQTT RELAY: invalid payload relay=%s payload=%s\n",
                    n.c_str(), msg.c_str());
      publishSystemError("INVALID_COMMAND", "Invalid relay command");
      return;
    }
    publishRelayStatus((uint8_t)i);
    Serial.printf("MQTT RELAY: relay=%s state=%s accepted=%s\n", n.c_str(),
                  relayOn((uint8_t)i) ? "ON" : "OFF", accepted ? "YES" : "NO");
    return;
  }
  String sp = String(MQTT_BASE) + "/schedule/";
  if (t.startsWith(sp) && t.endsWith("/set")) {
    String n = t.substring(sp.length(), t.length() - 4);
    int r = relayIndex(n);
    if (r < 0)
      return;
    ScheduleSlot previous[SLOT_COUNT] = {};
    for (uint8_t s = 0; s < SLOT_COUNT; s++) previous[s] = schedules[r][s];
    StaticJsonDocument<1024> d;
    if (msg.equalsIgnoreCase("DELETE")) {
      for (uint8_t s = 0; s < SLOT_COUNT; s++)
        schedules[r][s] = {false, 0, 0, 0, 0};
    } else {
      if (deserializeJson(d, msg)) {
        publishSystemError("INVALID_JSON", "Invalid schedule JSON");
        return;
      }
      JsonArray slots = d["slots"].as<JsonArray>();
      if (slots.isNull() || slots.size() > SLOT_COUNT) {
        Serial.printf("Schedule: rejected relay=%s reason=slot-count\n", relayNames[r]);
        publishSystemError("SCHEDULE_ERROR", "Invalid schedule slot count");
        queueTelegram(String("ปฏิเสธตารางของรีเลย์ ") + relayNames[r] + " เนื่องจากจำนวนช่วงเวลาไม่ถูกต้อง");
        return;
      }
      ScheduleSlot candidate[SLOT_COUNT] = {};
      bool malformed = false;
      for (uint8_t s = 0; s < SLOT_COUNT && s < slots.size(); s++) {
        JsonObject o = slots[s].as<JsonObject>();
        bool enabled = o["enabled"] | false;
        if (!enabled) continue;
        uint8_t oh, om, fh, fm;
        if (!parseHM(o["on"] | "", oh, om) || !parseHM(o["off"] | "", fh, fm)) {
          malformed = true;
          break;
        }
        candidate[s] = {true, oh, om, fh, fm};
      }
      if (malformed || !scheduleSetValid(candidate)) {
        const char *reason = malformed ? "invalid time" : "overlap";
        Serial.printf("Schedule: rejected relay=%s reason=%s\n", relayNames[r], reason);
        queueTelegram(String("ปฏิเสธตารางของรีเลย์ ") + relayNames[r] +
                      (malformed ? " เนื่องจากรูปแบบเวลาไม่ถูกต้อง" : " เนื่องจากเวลาชนกัน"));
        return;
      }
      for (uint8_t s = 0; s < SLOT_COUNT; s++) schedules[r][s] = candidate[s];
    }
    if (!saveConfig()) {
      for (uint8_t s = 0; s < SLOT_COUNT; s++) schedules[r][s] = previous[s];
      Serial.printf("Schedule: persistence failed relay=%s; previous schedule restored\n", relayNames[r]);
      publishScheduleStatus((uint8_t)r);
      queueTelegram(String("บันทึกตารางของรีเลย์ ") + relayNames[r] + " ไม่สำเร็จ จึงคืนค่าตารางเดิม");
      return;
    }
    uint16_t scheduleMinutes;
    if (scheduleClockMinutes(scheduleMinutes)) applyAutoState(scheduleMinutes);
    publishScheduleStatus((uint8_t)r);
    publishRelayStatus((uint8_t)r);
    queueTelegram(String("อัปเดตตารางเวลาของรีเลย์ ") + relayNames[r] +
                  " จากคำสั่ง MQTT");
    return;
  }
}

const char *mqttStateName(int8_t state) {
  switch (state) {
  case MQTT_CONNECTED:
    return "CONNECTED";
  case MQTT_CONNECT_BAD_PROTOCOL:
    return "BAD_PROTOCOL";
  case MQTT_CONNECT_BAD_CLIENT_ID:
    return "BAD_CLIENT_ID";
  case MQTT_CONNECT_UNAVAILABLE:
    return "SERVER_UNAVAILABLE";
  case MQTT_CONNECT_BAD_CREDENTIALS:
    return "BAD_CREDENTIALS";
  case MQTT_CONNECT_UNAUTHORIZED:
    return "UNAUTHORIZED";
  case MQTT_CONNECT_FAILED:
    return "CONNECT_FAILED";
  case MQTT_CONNECTION_TIMEOUT:
    return "TIMEOUT";
  default:
    return "UNKNOWN";
  }
}

void printMqttAuthDiagnosis(int8_t state) {
  if (state != MQTT_CONNECT_BAD_CREDENTIALS &&
      state != MQTT_CONNECT_UNAUTHORIZED)
    return;

  Serial.println(F("MQTT DIAG: authentication/authorization rejected by broker"));
  Serial.printf("MQTT DIAG: username=%s password=%s user_len=%u pass_len=%u\n",
                mqttUser[0] ? "PRESENT" : "MISSING",
                mqttPass[0] ? "PRESENT" : "MISSING",
                (unsigned)strlen(mqttUser), (unsigned)strlen(mqttPass));
  Serial.printf("MQTT DIAG: username_expected=%s username_matches=%s\n",
                MQTT_RECOMMENDED_USERNAME,
                strcmp(mqttUser, MQTT_RECOMMENDED_USERNAME) == 0 ? "YES" : "NO");
  Serial.printf("MQTT DIAG: broker=%s port=%u client_id=%s\n",
                MQTT_SERVER, MQTT_PORT, deviceName);
  Serial.println(F("MQTT DIAG: expected ACL allows command subscriptions and status publishes only"));
  Serial.println(F("MQTT DIAG: verify Access Management credential belongs to this Cluster"));
  Serial.println(F("MQTT DIAG: verify username/password exactly; values are case-sensitive"));
  Serial.println(F("MQTT DIAG: if credentials pass, verify role/permission matches explicit command topics"));
  Serial.println(F("MQTT DIAG: password value is never printed"));
}

void connectMqtt() {
  if (WiFi.status() != WL_CONNECTED) {
    return;
  }
  if (!mqttTlsReady) {
    if (!mqttConfigReported) {
      Serial.println(F("MQTT TLS: refusing connection until broker CA is installed"));
      mqttConfigReported = true;
    }
    return;
  }
  if (mqtt.connected())
    return;
  if (!mqttUser[0] || !mqttPass[0]) {
    if (!mqttConfigReported) {
      Serial.println(F("MQTT CONFIG: MISSING username/password"));
      Serial.println(F("MQTT CONFIG: open SmartFarm_Setup WiFi portal to enter "
                       "credentials"));
      mqttConfigReported = true;
    }
    return;
  }
  mqttConfigReported = false;

  // Prevent TLS certificate-time validation failures:
  // "Certificate is expired or not yet valid."
  // A valid CA alone is not enough; BearSSL also needs a valid clock.
  if (!prepareTlsValidationTime()) {
    if (!mqttConfigReported) {
      Serial.println(F("MQTT TLS: waiting for valid NTP/DS3231 time before handshake"));
      mqttConfigReported = true;
    }
    return;
  }

  if ((uint32_t)(millis() - lastMqttAttempt) < mqttRetryDelayMs)
    return;
  lastMqttAttempt = millis();
  mqttConnectAttempts++;
  normalizeMqttUsername();
  char clientId[56] = "";
  buildMqttClientId(clientId, sizeof(clientId));
  Serial.print(F("MQTT: Connecting to "));
  Serial.print(MQTT_SERVER);
  Serial.print(F(":"));
  Serial.println(MQTT_PORT);
  // Ensure a failed TLS handshake cannot leak a stale socket into the next try.
  tls.stop();
  Serial.printf("MQTT: Client ID=%s username=%s\n", clientId,
                strcmp(mqttUser, MQTT_RECOMMENDED_USERNAME) == 0 ? "recommended" : "custom");
  bool connected = mqtt.connect(clientId, mqttUser, mqttPass,
                                MQTT_BASE "/status/online", 0, true, "false");
  int8_t state = mqtt.state();
  if (connected) {
    mqttRetryDelayMs = MQTT_RECONNECT_MS;
    mqttAuthFailures = 0;
    mqtt.publish(MQTT_BASE "/status/online", "true", true);
    bool subscriptionsOk = true;
    for (uint8_t i = 0; i < MQTT_COMMAND_TOPIC_COUNT; ++i)
      subscriptionsOk = mqtt.subscribe(MQTT_COMMAND_TOPICS[i]) && subscriptionsOk;
    publishStatus();
    publishTelegramStatus();
    publishReminderStatus("online");
    publishAiAlertStatus("online");
    Serial.println(F("MQTT: Connected"));
    queueTelegram(F("เชื่อมต่อ MQTT สำเร็จ"));
    Serial.printf("MQTT: Subscribe command topics=%s\n",
                  subscriptionsOk ? "OK" : "FAIL");
    Serial.println(F("MQTT: READY"));
  } else {
    mqttRetryDelayMs = mqttRetryDelayMs >= MQTT_RECONNECT_MAX_MS / 2
        ? MQTT_RECONNECT_MAX_MS : mqttRetryDelayMs * 2;
    mqttConnectFailures++;
    Serial.printf("MQTT: Connect FAILED state=%d (%s), heap=%u\n", state,
                  mqttStateName(state), ESP.getFreeHeap());
    // A failed BearSSL handshake can retain socket state. Release it before
    // running diagnostics or the next retry, otherwise two TLS contexts may
    // compete for the ESP8266 heap.
    mqtt.disconnect();
    tls.stop();
    if (state == MQTT_CONNECT_FAILED)
      diagnoseMqttTransport();
    switch (state) {
    case MQTT_CONNECTION_TIMEOUT:
      Serial.println(F("MQTT ERROR: connection timeout"));
      break;
    case MQTT_CONNECT_BAD_PROTOCOL:
      Serial.println(F("MQTT ERROR: bad protocol"));
      break;
    case MQTT_CONNECT_BAD_CLIENT_ID:
      Serial.println(F("MQTT ERROR: bad client ID"));
      break;
    case MQTT_CONNECT_BAD_CREDENTIALS:
      Serial.println(F("MQTT ERROR: bad credentials"));
      printMqttAuthDiagnosis(state);
      break;
    case MQTT_CONNECT_UNAUTHORIZED:
      Serial.println(F("MQTT ERROR: unauthorized"));
      printMqttAuthDiagnosis(state);
      break;
    default:
      Serial.println(F("MQTT ERROR: unknown return code"));
      break;
    }
    if (state == MQTT_CONNECT_BAD_CREDENTIALS ||
        state == MQTT_CONNECT_UNAUTHORIZED) {
      mqttAuthFailures++;
      queueTelegram(
          String("MQTT เชื่อมต่อไม่สำเร็จ: credentials/authorization ผิด (ครั้งที่ ") +
          mqttAuthFailures + ")");
      if (mqttAuthFailures >= MQTT_AUTH_FAIL_LIMIT) {
        mqttAuthFailures = 0;
        // Never enter WiFiManager from the main loop. Its config portal is
        // intentionally blocking while a user is configuring it. Keep the
        // MQTT retry loop alive and let the operator open the portal with the
        // explicit OPEN_AP serial command or the Wi-Fi reset control.
        Serial.println(F("MQTT CONFIG: credentials rejected repeatedly; use OPEN_AP to edit settings"));
      }
    }
  }
}

void otaHttpCors() {
  // OTA is same-origin at the device's LAN URL. Do not expose a wildcard CORS
  // policy for an authenticated firmware-writing endpoint.
}

bool otaHttpAuthorized() {
  otaHttpCors();
  if (!otaPass[0]) {
    Serial.println(F("OTA HTTP: DISABLED - OTA password is not configured"));
    otaServer.send(503, "text/plain; charset=utf-8",
                   "OTA disabled: configure ota_pass first.");
    return false;
  }
  if (!otaServer.authenticate("admin", otaPass)) {
    otaServer.requestAuthentication(BASIC_AUTH, "SmartFarm OTA");
    return false;
  }
  return true;
}

void otaHttpUpload() {
  if (!otaHttpAuthorized())
    return;
  HTTPUpload &upload = otaServer.upload();
  if (upload.status == UPLOAD_FILE_START) {
    otaUploadFailed = false;
    otaUploadCompleted = false;
    otaUploadBytes = 0;
    otaHttpRestartPending = false;
    otaProgressPercent = 0;
    otaStartedAt = millis();
    otaLastProgressAt = millis();

    String filename = upload.filename;
    filename.toLowerCase();
    const bool validFilename = filename.length() > 4 &&
        filename.endsWith(".bin") && filename.indexOf("..") < 0 &&
        filename.indexOf('/') < 0 && filename.indexOf('\\') < 0;
    const size_t freeSketchSpace = ESP.getFreeSketchSpace();
    otaUploadMaxBytes = freeSketchSpace > 0x1000
        ? (freeSketchSpace - 0x1000) & 0xFFFFF000 : 0;
    Serial.printf("OTA HTTP: START %s, heap=%u, freeSketch=%u, maxImage=%u\n",
                  upload.filename.c_str(), ESP.getFreeHeap(),
                  (unsigned)freeSketchSpace, (unsigned)otaUploadMaxBytes);

    // Keep only the OTA path alive while flash is being written.
    enterOtaSafeState();

    if (!validFilename) {
      otaUploadFailed = true;
      Serial.println(F("OTA HTTP: REJECTED invalid filename; expected .bin"));
      leaveOtaSafeState();
    } else if (!otaUploadMaxBytes) {
      otaUploadFailed = true;
      Serial.println(F("OTA HTTP: REJECTED no free sketch space"));
      leaveOtaSafeState();
    } else if (!Update.begin(otaUploadMaxBytes, U_FLASH)) {
      otaUploadFailed = true;
      Update.printError(Serial);
      leaveOtaSafeState();
    }
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    if (!otaUploadFailed) {
      const size_t incoming = upload.currentSize;
      if (incoming > otaUploadMaxBytes ||
          otaUploadBytes > otaUploadMaxBytes - incoming) {
        otaUploadFailed = true;
        Serial.printf("OTA HTTP: REJECTED image too large bytes=%u max=%u\n",
                      (unsigned)otaUploadBytes, (unsigned)otaUploadMaxBytes);
        Update.end();
        leaveOtaSafeState();
        yield();
        return;
      }
      size_t written = Update.write(upload.buf, incoming);
      if (written != incoming) {
        otaUploadFailed = true;
        Update.printError(Serial);
      } else {
        otaUploadBytes += written;
        if (upload.totalSize > 0) {
          uint8_t percent = (uint8_t)((otaUploadBytes * 100UL) / upload.totalSize);
          if (percent != otaProgressPercent) {
            otaProgressPercent = percent;
            otaLastProgressAt = millis();
            if (percent % 10 == 0 || percent == 100)
              Serial.printf("OTA HTTP: progress %u%% heap=%u\n",
                            percent, ESP.getFreeHeap());
          }
        }
      }
    }
  } else if (upload.status == UPLOAD_FILE_END) {
    bool completeSize = upload.totalSize > 0 &&
                        upload.totalSize == otaUploadBytes;
    // Update.end(true) closes the flash writer and verifies the image before
    // any restart is allowed. A partial upload must never be booted.
    if (!otaUploadFailed && completeSize && Update.end(true)) {
      otaUploadCompleted = true;
      Serial.printf("OTA HTTP: END (%u bytes)\n", upload.totalSize);
    } else {
      otaUploadCompleted = false;
      if (!completeSize)
        Serial.printf("OTA HTTP: SIZE MISMATCH total=%u written=%u\n",
                      upload.totalSize, (unsigned)otaUploadBytes);
      Update.printError(Serial);
      Serial.println(F("OTA HTTP: FINALIZE FAILED"));
      leaveOtaSafeState();
    }
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    Update.end();
    otaUploadCompleted = false;
    otaUploadFailed = true;
    leaveOtaSafeState();
    Serial.println(F("OTA HTTP: ABORTED"));
  }
  yield();
}

void setupOtaHttpServer() {
  otaServer.on("/", HTTP_GET, []() {
    if (!otaHttpAuthorized())
      return;
    String page = F(
        "<!doctype html><html lang='en'><meta charset='utf-8'><meta "
        "name='viewport' "
        "content='width=device-width,initial-scale=1'><title>SmartFarm "
        "OTA</title><style>body{font:16px "
        "sans-serif;max-width:640px;margin:40px auto;padding:0 "
        "16px;background:#f5f7f5;color:#17251d}input,button{font:16px;padding:"
        "10px;margin:8px 0}button{cursor:pointer}</style><h1>SmartFarm "
        "OTA</h1><p>Firmware: ");
    page += SMARTFARM_VERSION;
    page += F("</p><dl><dt>Device</dt><dd id='device'>—</dd>"
              "<dt>IP</dt><dd id='ip'>—</dd><dt>RSSI</dt><dd id='rssi'>—</dd>"
              "<dt>Free Heap</dt><dd id='heap'>—</dd>"
              "<dt>Free Sketch Space</dt><dd id='space'>—</dd>"
              "<dt>OTA Status</dt><dd id='status'>—</dd>"
              "<dt>OTA Progress</dt><dd><progress id='progress' max='100' value='0'></progress> "
              "<span id='percent'>0%</span></dd></dl>"
              "<p class='warn'>ใช้เฉพาะ LAN ของสวน ห้าม Port Forward ไป Internet</p>"
              "<p>ก่อนเขียนเฟิร์มแวร์ ระบบจะปิดรีเลย์ทั้งหมดชั่วคราว "
              "หากล้มเหลว ระบบจะคงรีเลย์ OFF ไว้จนกว่าจะตรวจสาเหตุและรีสตาร์ตเอง "
              "ควรมีอุปกรณ์ตัดไฟฉุกเฉินภายนอกสำหรับโหลดจริง</p>"
              "<form id='upload' method='POST' action='/update' enctype='multipart/form-data'>"
              "<input id='file' type='file' name='firmware' accept='.bin' required><br>"
              "<button id='submit' type='submit'>Upload firmware</button></form>"
              "<pre id='result' role='status'></pre>"
              "<script>const $=id=>document.getElementById(id);"
              "async function refresh(){try{const r=await fetch('/api/status',{cache:'no-store'});"
              "if(!r.ok)return;const s=await r.json();$('device').textContent=s.device;"
              "$('ip').textContent=s.ip;$('rssi').textContent=s.rssi+' dBm';"
              "$('heap').textContent=s.freeHeap+' B';$('space').textContent=s.freeSketchSpace+' B';"
              "$('status').textContent=s.otaStatus;$('progress').value=s.otaProgress;"
              "$('percent').textContent=s.otaProgress+'%';}catch(_){}}"
              "refresh();setInterval(refresh,1500);$('upload').addEventListener('submit',e=>{"
              "e.preventDefault();const f=$('file').files[0];if(!f||!f.name.toLowerCase().endsWith('.bin')){"
              "$('result').textContent='เลือกไฟล์ .bin เท่านั้น';return;}"
              "if(!confirm('ยืนยันอัปเดต Firmware? รีเลย์ทั้งหมดจะปิดระหว่างเขียน'))return;"
              "const x=new XMLHttpRequest();x.open('POST','/update');"
              "x.upload.onprogress=e=>{if(e.lengthComputable){const p=Math.floor(e.loaded*100/e.total);"
              "$('progress').value=p;$('percent').textContent=p+'%';$('status').textContent='UPLOADING';}};"
              "x.onload=()=>{$('result').textContent=x.responseText;refresh();};"
              "x.onerror=()=>{$('result').textContent='Upload failed: network error';};"
              "x.send(new FormData($('upload')));});</script></html>");
    otaServer.send(200, "text/html; charset=utf-8", page);
  });
  otaServer.on(
      "/update", HTTP_POST,
      []() {
        if (!otaHttpAuthorized())
          return;
        bool ok = otaUploadCompleted && !otaUploadFailed && !Update.hasError();
        if (!ok) leaveOtaSafeState();
        otaHttpCors();
        otaServer.sendHeader("Connection", "close");
        String response = "Update complete. Device is restarting.";
        if (!ok) {
          const uint8_t errorCode = Update.hasError() ? Update.getError() : 255;
          const String errorReason = Update.hasError()
              ? Update.getErrorString() : String("validation/size/upload error");
          Serial.printf("OTA HTTP: ERROR code=%u reason=%s\n", errorCode,
                        errorReason.c_str());
          response = String("Update failed code=") + errorCode + " reason=" + errorReason;
        }
        otaServer.send(ok ? 200 : 500, "text/plain; charset=utf-8", response);
        if (ok) {
          // Give the HTTP response and browser upload completion time to leave
          // the socket before reboot. The image has already been finalized and
          // verified above; a failed or partial upload never reaches this path.
          otaHttpRestartPending = true;
          otaHttpRestartAt = millis() + 3000UL;
        }
      },
      otaHttpUpload);
  otaServer.on("/api/status", HTTP_GET, []() {
    if (!otaHttpAuthorized())
      return;
    StaticJsonDocument<384> d;
    d["device"] = deviceName;
    d["firmware"] = SMARTFARM_VERSION;
    d["ip"] = WiFi.localIP().toString();
    d["rssi"] = WiFi.RSSI();
    d["otaReady"] = otaReady;
    d["otaInProgress"] = otaUpdateInProgress;
    d["otaProgress"] = otaProgressPercent;
    d["otaStatus"] = otaUpdateInProgress ? "UPDATING"
        : (otaFailureLock || otaUploadFailed) ? "ERROR"
        : otaUploadCompleted ? "RESTARTING"
        : otaReady ? "READY" : "DISABLED";
    d["otaPort"] = OTA_ARDUINO_PORT;
    d["httpOtaPort"] = OTA_HTTP_PORT;
    d["freeHeap"] = ESP.getFreeHeap();
    d["freeSketchSpace"] = ESP.getFreeSketchSpace();
    String out;
    serializeJson(d, out);
    otaServer.send(200, "application/json", out);
  });
  otaServer.on("/", HTTP_OPTIONS, []() {
    otaHttpCors();
    otaServer.send(204);
  });
  otaServer.on("/update", HTTP_OPTIONS, []() {
    otaHttpCors();
    otaServer.send(204);
  });
  otaServer.on("/api/status", HTTP_OPTIONS, []() {
    otaHttpCors();
    otaServer.send(204);
  });
  otaServer.onNotFound([]() {
    otaHttpCors();
    otaServer.send(404, "text/plain", "Not found");
  });
  otaServer.begin(OTA_HTTP_PORT);
  Serial.print(F("OTA HTTP READY: http://"));
  Serial.print(WiFi.localIP());
  Serial.println(F("/  (LAN only, password required)"));
}

void clearSavedWifiSettings(const __FlashStringHelper *source,
                            bool restartDevice = true) {
  Serial.print(source);
  Serial.println(F("; clearing saved Wi-Fi settings"));
  mqtt.disconnect();
  WiFiManager wm;
  wm.resetSettings();
  WiFi.disconnect(true);
  if (restartDevice) {
    delay(500);
    ESP.restart();
  }
}

bool resetWifiIfButtonHeldAtBoot() {
  if (digitalRead(WIFI_RESET_BUTTON) != LOW) return false;
  Serial.println(F("WiFi reset button detected at boot; hold for 5 seconds"));
  uint32_t startedAt = millis();
  while (digitalRead(WIFI_RESET_BUTTON) == LOW) {
    if ((uint32_t)(millis() - startedAt) >= WIFI_RESET_HOLD_MS) {
      clearSavedWifiSettings(F("BOOT WiFi reset confirmed"), false);
      // Do not restart while the physical button is still held. Otherwise the
      // next boot sees the same LOW level and clears/restarts again forever.
      wifiResetLatched = true;
      wifiResetPressed = false;
      wifiResetStartedAt = 0;
      return true;
    }
    delay(25);
    yield();
  }
  Serial.println(F("WiFi reset cancelled before 5 seconds"));
  return false;
}

void handleWifiResetButton() {
  const bool pressed = digitalRead(WIFI_RESET_BUTTON) == LOW;

  if (wifiResetLatched) {
    if (!pressed) {
      wifiResetLatched = false;
      Serial.println(F("WiFi reset latch released"));
    }
    return;
  }

  if (pressed && !wifiResetPressed) {
    wifiResetPressed = true;
    wifiResetStartedAt = millis();
    Serial.println(F("WiFi reset button pressed; hold for 5 seconds"));
  }

  if (!pressed) {
    if (wifiResetPressed)
      Serial.println(F("WiFi reset cancelled"));
    wifiResetPressed = false;
    wifiResetStartedAt = 0;
    return;
  }

  if ((uint32_t)(millis() - wifiResetStartedAt) < WIFI_RESET_HOLD_MS)
    return;

  clearSavedWifiSettings(F("WiFi reset confirmed"));
}

void handleApSetupButton() {
  // GPIO16 (D0) has a built-in pull-down; the momentary button connects it to
  // 3.3 V. Unlike the D1 Wi-Fi reset button, this input never clears settings.
  const bool pressed = digitalRead(AP_SETUP_BUTTON) == HIGH;

  if (apSetupButtonLatched) {
    if (!pressed) {
      apSetupButtonLatched = false;
      Serial.println(F("AP setup button released"));
    }
    return;
  }

  if (pressed && !apSetupButtonPressed) {
    apSetupButtonPressed = true;
    apSetupButtonStartedAt = millis();
    Serial.println(F("AP setup button pressed; hold for 2 seconds"));
  }

  if (!pressed) {
    if (apSetupButtonPressed)
      Serial.println(F("AP setup button cancelled"));
    apSetupButtonPressed = false;
    apSetupButtonStartedAt = 0;
    return;
  }

  if ((uint32_t)(millis() - apSetupButtonStartedAt) <
      AP_SETUP_BUTTON_HOLD_MS)
    return;

  apSetupButtonLatched = true;
  apSetupButtonPressed = false;
  apSetupButtonStartedAt = 0;
  for (uint8_t i = 0; i < RELAY_COUNT; i++) {
    if (relayOn(i)) {
      Serial.printf("AP setup blocked: relay %s is ON; turn all relays OFF first\n",
                    relayNames[i]);
      return;
    }
  }
  Serial.println(F("AP setup requested; saved Wi-Fi settings will be kept"));
  openMqttSetupPortal();
}

void handleSerialCommands() {
  if (!Serial.available()) return;
  String command = Serial.readStringUntil('\n');
  command.trim();
  command.toUpperCase();
  if (command == "RESET_WIFI" || command == "RESET WIFI" || command == "WIFI_RESET") {
    clearSavedWifiSettings(F("SERIAL WiFi reset received"));
  } else if (command == "OPEN_AP") {
    Serial.println(F("SERIAL: OPEN_AP received; opening SmartFarm_Setup"));
    openMqttSetupPortal();
  } else {
    Serial.println(F("SERIAL: commands are RESET_WIFI, RESET WIFI, WIFI_RESET or OPEN_AP"));
  }
}

void setupWifi() {
  WiFi.mode(WIFI_STA);
  // Keep the selected Wi-Fi credentials in flash across power cycles.
  WiFi.setAutoReconnect(true);
  WiFi.persistent(true);
  pinMode(WIFI_RESET_BUTTON, INPUT_PULLUP);
  pinMode(AP_SETUP_BUTTON, INPUT_PULLDOWN_16);
  resetWifiIfButtonHeldAtBoot();
  WiFiManager wm;
  wm.setConfigPortalTimeout(WIFI_PORTAL_TIMEOUT_SECONDS);
  loadSecrets();
  pUser.setValue(mqttUser, sizeof(mqttUser));
  pPass.setValue(mqttPass, sizeof(mqttPass));
  pOta.setValue(otaPass, sizeof(otaPass));
  pTelegramToken.setValue(telegramBotToken, sizeof(telegramBotToken));
  pTelegramChat.setValue(telegramChatId, sizeof(telegramChatId));
  pName.setValue(deviceName, sizeof(deviceName));
  wm.addParameter(&pUser);
  wm.addParameter(&pPass);
  wm.addParameter(&pOta);
  wm.addParameter(&pTelegramToken);
  wm.addParameter(&pTelegramChat);
  wm.addParameter(&pName);
  Serial.println(F("WiFiManager: connecting to saved AP (credentials persist in flash)..."));
  if (!wm.autoConnect("SmartFarm_Setup")) {
    // autoConnect() may block until the portal timeout, but a timeout must
    // not turn into an unconditional reboot loop. Continue in STA mode and
    // let maintainWifi() retry in the normal loop.
    Serial.println(F("WiFiManager portal timeout/failed; continuing offline without restart"));
    WiFi.mode(WIFI_STA);
    wifiStateKnown = false;
    return;
  }
  strlcpy(mqttUser, pUser.getValue(), sizeof(mqttUser));
  strlcpy(mqttPass, pPass.getValue(), sizeof(mqttPass));
  strlcpy(otaPass, pOta.getValue(), sizeof(otaPass));
  strlcpy(telegramBotToken, pTelegramToken.getValue(),
          sizeof(telegramBotToken));
  strlcpy(telegramChatId, pTelegramChat.getValue(), sizeof(telegramChatId));
  strlcpy(deviceName, pName.getValue(), sizeof(deviceName));
  if (!saveSecrets()) Serial.println(F("Credential persistence failed after WiFi setup"));
  Serial.print(F("WiFi connected, IP: "));
  Serial.println(WiFi.localIP());
  if (!mqttUser[0] || !mqttPass[0]) {
    Serial.println(
        F("MQTT CONFIG: credentials not saved - opening setup portal"));
    openMqttSetupPortal();
  }
}

void setup() {
  Serial.begin(115200);
  snprintf(otaHostname, sizeof(otaHostname), "SmartFarm-%06X", ESP.getChipId());
  delay(100);
  Serial.printf("\n====================================\nสวนลุงนะ Smart Farm\nFirmware: %s\nDevice: %s\nESP8266 NodeMCU 1.0 (ESP-12E)\n====================================\n",
                SMARTFARM_VERSION, otaHostname);
  Serial.print(F("Reset reason: "));
  Serial.println(ESP.getResetReason());
  Serial.print(F("Reset info: "));
  Serial.println(ESP.getResetInfo());
  Serial.print(F("Free heap at boot: "));
  Serial.println(ESP.getFreeHeap());
  pinMode(WIFI_RESET_BUTTON, INPUT_PULLUP);
  pinMode(AP_SETUP_BUTTON, INPUT_PULLDOWN_16);
  for (uint8_t i = 0; i < RELAY_COUNT; i++) {
    // Preload the OFF output latch before switching the GPIO to OUTPUT to
    // reduce transients after setup starts. Strap-pin behavior during reset
    // is a hardware constraint; see OTA guide for D8/GPIO15 relay caveat.
    digitalWrite(relayPins[i], RELAY_OFF);
    pinMode(relayPins[i], OUTPUT);
    digitalWrite(relayPins[i], RELAY_OFF);
  }
  initFS();
  loadConfig();
  loadReminders();
  initRTC();
  dht.begin();
  ntp.begin();
  Serial.print(F("Heap before WiFi: "));
  Serial.println(ESP.getFreeHeap());
  setupWifi();
  Serial.print(F("Heap after WiFi: "));
  Serial.println(ESP.getFreeHeap());
  // NTP must be synchronized before TLS certificate validation.
  // DS3231 is updated from NTP and can then be used as the fallback clock.
  syncRTCFromNTP(true);
  reportClockStatus();
  Serial.printf("WiFi: %s IP: %s RSSI: %ld dBm\n",
                WiFi.status() == WL_CONNECTED ? "CONNECTED" : "OFFLINE",
                WiFi.localIP().toString().c_str(),
                WiFi.status() == WL_CONNECTED ? WiFi.RSSI() : 0L);
  Serial.printf("MQTT: %s TLS port %u\n",
                mqttUser[0] && mqttPass[0] ? "CONFIGURED" : "NEEDS CREDENTIALS",
                MQTT_PORT);
  Serial.println(F("DHT11: D2 / GPIO4"));
  Serial.printf("RTC: DS3231 %s (D3 SDA / D4 SCL); NTP %s\n",
                rtcAvailable ? "AVAILABLE" : "NOT FOUND",
                ntpTimeValid ? "VALID" : "NOT VALID");

  mqttTlsReady = configureMqttTls();
  mqtt.setServer(MQTT_SERVER, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
  mqtt.setSocketTimeout(5);
  mqtt.setKeepAlive(30);
  // Keep both MQTT and TLS buffers small; current payloads fit comfortably.
  mqtt.setBufferSize(768);
  uint16_t bootMinutes;
  if (scheduleClockMinutes(bootMinutes)) applyAutoState(bootMinutes);
  // Use a stable hostname for discovery and a fixed UDP port for Arduino IDE.
  ArduinoOTA.setHostname(otaHostname);
  ArduinoOTA.setPort(OTA_ARDUINO_PORT);

  ArduinoOTA.onStart([]() {
    enterOtaSafeState();
    Serial.println(F("OTA: START - ArduinoOTA"));
  });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    if (!total) return;
    uint8_t percent = (uint8_t)((progress * 100UL) / total);
    if (percent != otaProgressPercent) {
      otaProgressPercent = percent;
      otaLastProgressAt = millis();
      if (percent % 10 == 0 || percent == 100) {
        Serial.printf("OTA: progress %u%% heap=%u\n",
                      percent, ESP.getFreeHeap());
      }
    }
    yield();
  });

  ArduinoOTA.onEnd([]() {
    otaProgressPercent = 100;
    Serial.println(F("OTA: END - image accepted; rebooting"));
  });

  ArduinoOTA.onError([](ota_error_t e) {
    const char *errorName = "OTA_UNKNOWN_ERROR";
    switch (e) {
    case OTA_AUTH_ERROR: errorName = "OTA_AUTH_ERROR"; break;
    case OTA_BEGIN_ERROR: errorName = "OTA_BEGIN_ERROR"; break;
    case OTA_CONNECT_ERROR: errorName = "OTA_CONNECT_ERROR"; break;
    case OTA_RECEIVE_ERROR: errorName = "OTA_RECEIVE_ERROR"; break;
    case OTA_END_ERROR: errorName = "OTA_END_ERROR"; break;
    }
    otaUploadFailed = true;
    Serial.printf("OTA: ERROR %s (%u)\n", errorName, e);
    leaveOtaSafeState();
  });

  if (otaPass[0]) {
    ArduinoOTA.setPassword(otaPass);
    ArduinoOTA.begin();
    otaReady = true;
    Serial.printf("OTA: ArduinoOTA READY host=%s port=%u IP=%s\n",
                  otaHostname, OTA_ARDUINO_PORT, WiFi.localIP().toString().c_str());
  } else {
    otaReady = false;
    Serial.println(F("OTA: DISABLED - configure ota_pass in SmartFarm_Setup"));
  }

#if ENABLE_HTTP_OTA
  setupOtaHttpServer();
#else
  Serial.println(F("OTA HTTP: DISABLED"));
#endif
  Serial.print(F("MQTT server: "));
  Serial.print(MQTT_SERVER);
  Serial.print(F(":"));
  Serial.println(MQTT_PORT);
  Serial.print(F("MQTT credentials: "));
  Serial.println((mqttUser[0] && mqttPass[0]) ? F("PRESENT") : F("MISSING"));
  Serial.print(F("Boot complete, heap: "));
  Serial.println(ESP.getFreeHeap());
  queueTelegram(String("อุปกรณ์บูตสำเร็จ IP=") + WiFi.localIP().toString() +
                " firmware=" + SMARTFARM_VERSION);
}

void runSafety() {
  if (!relayOn(0)) {
    pumpStartedAt = 0;
    return;
  }
  if (!pumpStartedAt)
    pumpStartedAt = millis();
  // ไม่มีเพดานเวลาทำงานแบบ 30 นาที รีเลย์จะทำตามตารางหรือคำสั่งล่าสุด
  // การหลุด MQTT ต้องไม่ตัดการรดน้ำอัตโนมัติที่เก็บไว้ใน ESP8266
}
void runSchedules() {
  if (otaUpdateInProgress) return;
  if ((uint32_t)(millis() - lastSchedule) < SCHEDULE_INTERVAL_MS)
    return;
  lastSchedule = millis();
  // Prefer the DS3231, but keep schedules running from validated NTP when RTC is unavailable.
  uint16_t scheduleMinutes;
  if (!scheduleClockMinutes(scheduleMinutes)) return;
  applyAutoState(scheduleMinutes);
}

void publishHeartbeat() {
  if (!mqtt.connected())
    return;
  // The heartbeat includes diagnostics, sensor age, and an ISO timestamp.
  // 512 bytes truncates the JSON before the closing brace, so browser clients
  // cannot parse status/device and incorrectly keep ESP8266 offline.
  StaticJsonDocument<1024> d;
  d["device_id"] = deviceName[0] ? deviceName : "esp8266-01";
  d["online"] = true;
  d["wifi"] = WiFi.status() == WL_CONNECTED;
  d["mqtt"] = mqtt.connected();
  d["firmware"] = SMARTFARM_VERSION;
  d["otaReady"] = otaReady;
  d["otaInProgress"] = otaUpdateInProgress;
  d["otaStatus"] = otaUpdateInProgress ? "UPDATING"
      : otaUploadFailed ? "ERROR"
      : otaUploadCompleted ? "RESTARTING"
      : otaReady ? "READY" : "DISABLED";
  d["otaPort"] = OTA_ARDUINO_PORT;
  d["httpOtaPort"] = OTA_HTTP_PORT;
  d["otaProgress"] = otaProgressPercent;
  d["heap"] = ESP.getFreeHeap();
  d["heapMaxBlock"] = ESP.getMaxFreeBlockSize();
  d["heapFrag"] = ESP.getHeapFragmentation();
  d["rssi"] = WiFi.RSSI();
  d["uptime"] = millis() / 1000UL;
  d["uptimeSec"] = millis() / 1000UL;
  d["resetReason"] = ESP.getResetReason();
  d["wifiReconnects"] = wifiReconnectRequests;
  d["mqttConnects"] = mqttConnectAttempts;
  d["mqttFailures"] = mqttConnectFailures;
  d["pumpSafeLock"] = pumpSafetyLatched;
  d["emergencyLock"] = emergencyLock;
  d["emergencySource"] = emergencySource;
  d["mode"] = autoMode ? "AUTO" : "MANUAL";
  JsonObject relayState = d.createNestedObject("relays");
  for (uint8_t i = 0; i < RELAY_COUNT; i++)
    relayState[relayNames[i]] = relayOn(i);
  d["pumpRuntimeSec"] = relayOn(0) && pumpStartedAt
                             ? (millis() - pumpStartedAt) / 1000UL
                             : 0;
  String iso = rtcIso();
  bool rtcNowValid = rtcAvailable && rtcTimeValid && iso.length();
  d["clockValid"] = rtcNowValid || (ntpTimeValid && ntp.getEpochTime() >= MIN_VALID_EPOCH);
  d["rtc"] = rtcNowValid;
  d["ntp"] = ntpTimeValid;
  d["clockSource"] = rtcNowValid ? "rtc" : (ntpTimeValid ? "ntp" : "none");
  d["sensorReads"] = sensorReadCount;
  d["sensorFaults"] = sensorFaultCount;
  d["sensorAgeSec"] = lastSensorValidAt
                           ? (millis() - lastSensorValidAt) / 1000UL
                           : 0;
  d["sensorOk"] = lastSensorValidAt &&
                  (uint32_t)(millis() - lastSensorValidAt) <= 90000UL;
  if (iso.length())
    d["time"] = iso;
  char out[1024];
  const size_t written = serializeJson(d, out, sizeof(out));
  if (written == 0 || written >= sizeof(out) - 1) return;
  // Retain the latest heartbeat so a freshly opened dashboard can restore RTC time immediately.
  mqtt.publish(MQTT_BASE "/status/device", out, true);
}

void loop() {
  ESP.wdtFeed();

  // OTA must get the highest priority on ESP8266. During a firmware upload
  // avoid MQTT, Telegram, sensor I/O and scheduling so the flash stream is
  // not starved by TLS allocations or blocking network work.
  ArduinoOTA.handle();
  otaServer.handleClient();
  if (otaHttpRestartPending && (int32_t)(millis() - otaHttpRestartAt) >= 0) {
    Serial.println(F("OTA HTTP: verified image staged; restarting now"));
    ESP.restart();
  }
  if (otaUpdateInProgress) {
    ESP.wdtFeed();
    yield();
    return;
  }

  handleSerialCommands();
  handleWifiResetButton();
  handleApSetupButton();
  maintainWifi();
  reportWifiState();
  if (WiFi.status() == WL_CONNECTED) {
    connectMqtt();
    if (mqtt.connected())
      mqtt.loop();
    ntp.update();
    syncRTCFromNTP(false);
  } else {
  }
  runSafety();
  runSchedules();
  runReminders();
  if ((uint32_t)(millis() - lastSensor) >= SENSOR_INTERVAL_MS) {
    lastSensor = millis();
    float h = dht.readHumidity(), c = dht.readTemperature();
    sensorReadCount++;
    if (isfinite(h) && isfinite(c)) {
      lastSensorValidAt = millis();
    } else {
      sensorFaultCount++;
      Serial.printf("DHT11: invalid reading #%lu\n", (unsigned long)sensorFaultCount);
    }
    if (mqtt.connected() && isfinite(h) && isfinite(c)) {
      StaticJsonDocument<160> d;
      d["temperature"] = c;
      d["humidity"] = h;
      d["unit_temperature"] = "C";
      d["unit_humidity"] = "%";
      String sensorIso = rtcIso();
      if (sensorIso.length()) d["timestamp"] = sensorIso;
      char out[256];
      serializeJson(d, out, sizeof(out));
      mqtt.publish(MQTT_BASE "/sensor/dht11", out, false);
    }
  }
  if ((uint32_t)(millis() - lastHeartbeat) >= HEARTBEAT_INTERVAL_MS) {
    lastHeartbeat = millis();
    publishHeartbeat();
  }
  processTelegramQueue();
  yield();
}
